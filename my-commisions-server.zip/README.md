# Web Server for MyCommisions 

## Table of Contents  
- [Overview](#overview)  
- [Features](#features)   
- [Development](#development)  
  - [Prerequisites](#prerequisites)   
  - [Running Locally](#running-locally)   
- [Environment Variables](#environment-variables)  

---

## Overview  
This is the web server for MyCommisions, a platform for artist and customer

---

## Features  
- User authentication and authorization   

---

## Development   

### Prerequisites 
- npm i
- npx prisma migrate dev --name init 

### Running Locally
- npm run dev

---

## Environment Variables
.env.example

---