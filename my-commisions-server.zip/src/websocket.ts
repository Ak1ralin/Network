import { Server as HttpServer } from 'http';
import { Server as SocketIOServer, Socket } from 'socket.io';


let io: SocketIOServer;

export const initializeSocket = (server: HttpServer) => {
    io = new SocketIOServer(server, {
        cors: { origin: '*', methods: ['GET', 'POST'] },
    });

    io.on("connection", (socket) => {
        // console.log(`New client connected: ${socket.id}`)

        socket.on("joinRoom", async ({ senderId, chatRoomId }) => {
            
            socket.join(chatRoomId)
            // socket.emit("roomJoined", chatRoomId)
            console.log(`Sender Id:${senderId} Join Chat Room : ${chatRoomId}`)
        })

        socket.on("disconnect", () => {
            console.log(`Client disconnected: ${socket.id}`);
        })

    })
};

export const getSocketInstance = (): SocketIOServer => {
    if (!io) throw new Error('Socket.io not initialized');
    return io;
};