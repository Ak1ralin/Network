import z from 'zod'
import { createValidator } from './main';

const itemSchema = z.object({
    id: z.string(),
    name: z.string().min(1, "Name is required"), 
    quantity: z.number().positive("Quantity must be a positive number"),
    price: z.number().positive("Price must be a positive number")
});

const lineItemsSchema = z.object({
    line_items: z.array(itemSchema)
});

export const itemsValidator = createValidator({bodySchema:lineItemsSchema})