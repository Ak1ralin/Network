import { z } from "zod";
import { createValidator } from "./main";

const registerSchema = z.object({
    firstName: z.string(),
    lastName: z.string(),
    birthDate: z.string().date(),
    phone: z.string().length(10, "Not a phone number"),
    displayName: z.string().max(72, "Too long display name"),
    email: z.string().email("Enter a valid email"),
    password: z.string(),
});

const loginSchema = z.object({
    email: z.string().email("Invalid email format"),
    password: z.string(),
})

export const registerValidator = createValidator({ bodySchema: registerSchema });
export const loginValidator = createValidator({ bodySchema: loginSchema });