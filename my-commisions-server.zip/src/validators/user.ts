import { z } from "zod";
import { createValidator } from "./main";

const userIdParam = z.object({
    userId: z.string().uuid(),
})

const userSchema = z.object({
    userId: z.string().uuid("Must be a uuid").optional(),
    firstName: z.string().optional(),
    lastName: z.string().optional(),
    birthDate: z.string().date().optional(),
    phone: z.string().length(10, "Not a phone number").optional(),
    displayName: z.string().max(72, "Too long display name").optional(),
    email: z.string().email("Enter a valid email").optional(),
});

const changePassword = z.object({
    oldPassword: z.string(),
    newPassword: z.string(),
})

export const userIdParamValidator = createValidator({ paramSchema: userIdParam });
export const updateUserValidator = createValidator({ bodySchema: userSchema });
export const changePasswordValidator = createValidator({ bodySchema: changePassword, paramSchema: userIdParam });