import { z } from "zod";
import { createValidator } from "./main";

const createReviewSchema = z.object({
    rating: z.number().min(0.5).max(5),
    description: z.string().optional()
})

export const createReviewValidator = createValidator({ bodySchema: createReviewSchema });