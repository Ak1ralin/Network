import { Request, Response, NextFunction } from "express";
import { ZodSchema } from "zod";

interface Schemas {
    paramSchema?: ZodSchema,
    querySchema?: ZodSchema,
    bodySchema?: ZodSchema,
}

export const createValidator = ({
    paramSchema,
    bodySchema,
    querySchema,
}: Schemas) => {
    return (req: Request, res: Response, next: NextFunction) => {

        if (paramSchema) {
            const result = paramSchema.safeParse(req.params);
            if (!result.success) {
                res.status(422).json({ errors: result.error.format() });
                return;
            }
        }
        
        if (querySchema) {
            const result = querySchema.safeParse(req.query);
            if (!result.success) {
                res.status(422).json({ errors: result.error.format() });
                return;
            }
        }

        if (bodySchema) {
            const result = bodySchema.safeParse(req.body);
            if (!result.success) {
                console.log(result.error);
                res.status(422).json({ errors: result.error.format() });
                return;
            }
        }


        next();
    };
};
