import { z } from "zod";
import { createValidator } from "./main";

// Define the ReportType Enum
const ReportTypeEnum = z.enum(["GENERAL", "COMMISSION", "USER", "POST"]);

// Define the ReportStatus Enum (for Admin edit only)
const ReportStatusEnum = z.enum(["PENDING", "IN_REVIEW", "APPROVED", "REJECTED"]);

// Validation Schema for Creating a Report
const createReportSchema = z
    .object({
        reportType: ReportTypeEnum,
        reportDescription: z.string().max(2048, "Report description is too long."),
        commissionId: z.string().uuid().optional(), // Required if reportType is COMMISSION
        reporteeId: z.string().uuid().optional(), // Required if reportType is USER
        postId: z.string().uuid().optional(), // Required if reportType is POST
    })
    .refine(
        (data) => {
            if (data.reportType === "COMMISSION" && !data.commissionId) return false;
            if (data.reportType === "USER" && !data.reporteeId) return false;
            if (data.reportType === "POST" && !data.postId) return false;
            return true;
        },
        {
            message: "ID associated with the report type is required.",
            path: ["reportType"],
        }
    );

// Validation Schema for Editing a Report (Admin only)
const editReportSchema = z.object({
    reportType: ReportTypeEnum.optional(),
    reportDescription: z.string().max(2048, "Report description is too long.").optional(),
    commissionId: z.string().uuid().optional(),
    reporteeId: z.string().uuid().optional(),
    postId: z.string().uuid().optional(),
    reportStatus: ReportStatusEnum.optional(), // Admin can update the report status
    moderatorResponse: z.string().max(2048, "Moderator response is too long.").optional(),
});

export const createReportValidator = createValidator({ bodySchema: createReportSchema });
export const editReportValidator = createValidator({ bodySchema: editReportSchema });
