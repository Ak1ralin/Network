import { z } from "zod";
import { createValidator } from "./main";

// status must be these values
const StatusEnum = z.enum([
    "BRIEF",
    "BRIEF_REJECTED",
    "PROPOSAL",
    "PROPOSAL_REJECTED",
    "WORKING",
    "ARTWORK_SHIPPED",
    "ARTWORK_REJECTED",
    "FINISHED",
    "CANCELED",
]);

const commissionIdParam = z.object({
    commissionId: z.string().uuid("Invalid Commission ID format."),
})

const createCommissionSchema = z.object({
    customerId: z.string().uuid("Invalid Customer ID format."),
    artistId: z.string().uuid("Invalid Artist ID format."),
    chatRoomId: z.string().uuid("Invalid chat room ID format."),
    commissionName: z.string().max(512, "Commission name is too long."),
    briefDescription: z.string().max(2048, "Brief Description is too long."),
    budget: z.number().nonnegative("Budget must be a positive value."),
    deadline: z.coerce.date().refine((date) => new Date(date) > new Date(), {
        message: "Deadline must be a future date.",
    }),
});

const sendBriefSchema = z.object({
    briefDescription: z.string().max(2048, "Brief Description is too long."),
    budget: z.number().nonnegative("Budget must be a positive value."),
});

const sendProposalSchema = z.object({
    expectedDate: z.coerce.date().refine((date) => date > new Date(), {
        message: "expected date must be a future date.",
    }),
    proposalPrice: z.number().nonnegative("Proposal price must be a positive value."),
});

const sendArtworkSchema = z.object({
    // imageUrl: z.string().url("Invalid image URL."),
    imageUrl: z.string(),
    customerHide: z.boolean().optional(),
    artistHide: z.boolean().optional(),
});

const editCommissionSchema = z.object({
    customerId: z.string().uuid("Invalid Customer ID format.").optional(),
    artistId: z.string().uuid("Invalid Artist ID format.").optional(),
    state: StatusEnum.optional(),
    transactionId: z.string().uuid("Invalid Transaction ID format.").optional(),
    artworkId: z.string().uuid("Invalid Artwork ID format.").optional(),
    briefDescription: z.string().max(2048, "Brief Description is too long.").optional(),
    dueDate: z.coerce
        .date()
        .refine((date) => date > new Date(), {
            message: "Due date must be a future date.",
        })
        .optional(),
    budget: z.number().nonnegative("Budget must be a positive value.").optional(),
    proposalPrice: z.number().nonnegative("Proposal price must be a positive value.").optional(),
});

export const createCommissionValidator = createValidator({ bodySchema: createCommissionSchema });
export const sendBriefValidator = createValidator({ bodySchema: sendBriefSchema });
export const sendProposalValidator = createValidator({ bodySchema: sendProposalSchema });
export const sendArtworkValidator = createValidator({ bodySchema: sendArtworkSchema });
export const commissionIdValidator = createValidator({ paramSchema: commissionIdParam });

// Admin only
export const editCommissionValidator = createValidator({ bodySchema: editCommissionSchema });
