import { z } from "zod";
import { createValidator } from "./main";

// copied from front end (05/02/2025)
const availableTags = [
    "Realism", "Semi-Realism", "Anime/Manga", "Chibi", "Portrait", "Fan Art", "OC", "Digital Art",
    "Traditional Art", "Watercolor", "Oil Painting", "Pencil Sketch", "Pixel Art",
] as const;

const  TagEnum = z.enum(availableTags);

// Expected Body
// const postData = {
//     name: "title",
//     description: "description",
//     tags: ["Anime/Manga", "Chibi"],
//     price: 999,
//     samples: ["http://test.url", "http://image.here"],
//     isHide: false, (optional)
//     ... (stop checking schema here)
//     userId: ..., (for user validation)
// };

const createPostSchema = z.object({
    // postName: z.string().max(72, "Post Title is too long."),
    postDescription: z.string().max(2048, "Post Description is too long."),
    postTags: z.array(TagEnum),
    // price: z.number().nonnegative("Price must be more than zero.").lte(1000000, "Price cannot exceed 1,000,000 THB."),
    isHide: z.boolean().optional(),
});

const editPostSchema = z.object({
    // postName: z.string().max(72, "Post Title is too long.").optional(),
    postDescription: z.string().max(2048, "Post Description is too long.").optional(),
    postTags: z.array(TagEnum).optional(),
    // price: z.number().nonnegative("Price must be more than zero.").lte(1000000, "Price cannot exceed 1,000,000 THB.").optional(),
    isHide: z.boolean().optional(),
});

export const createPostValidator = createValidator({ bodySchema: createPostSchema });
export const editPostValidator = createValidator({ bodySchema: editPostSchema });