import prisma from "../database/prisma";
import { AppError } from "../utils/AppError";

export const createCommission = async (commissionData: any) => {
    try {

        const { artistId, customerId, chatRoomId, deadline, ...other } = commissionData;

        const newCommission = await prisma.commission.create({
            data: {
                ...other,
                deadline: new Date(deadline),
                artist: { connect: { userId: artistId}},
                customer: { connect: { userId: customerId }},
                chatRoom: { connect: { chatRoomId: chatRoomId }}
            },
            
        });

        if (!newCommission) {
            throw new AppError("Error creating commission", 500);
        }

        return newCommission;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const getCommissionById = async (commissionId: string) => {
    try {
        const commission = await prisma.commission.findUnique({
            where: { commissionId },
            include: {
                // customer: false,
                // artist: false,
                artwork: true,
                transaction: true,
            },
        });

        if (!commission) {
            throw new AppError("Commission not found", 404);
        }

        return commission;
    } catch (err) {
        throw err;
    }
};

export const getCommissionsByUser = async (userId: string) => {
    try {
        const commissions = await prisma.commission.findMany({
            where: {
                OR: [{ customerId: userId }, { artistId: userId }],
            },
            include: {
                customer: true,
                artist: true,
                artwork: true,
                transaction: true,
            },
        });

        if (!commissions.length) {
            throw new AppError("No commissions found", 404);
        }

        return commissions;
    } catch (err) {
        throw err;
    }
};

export const getArtworksByUser = async (userId: string) => {
    try {
        const artworks = await prisma.artwork.findMany({
            where: {
                artistId: userId,
                customerHide: false,
                artistHide: false,
            },
        });

        if (!artworks.length) {
            throw new AppError("No artworks found", 404);
        }

        return artworks;
    } catch (err) {
        throw err;
    }
};

export const updateCommission = async (commissionId: string, updateData: any) => {
    // console.log(commissionId);
    try {
        const updatedCommission = await prisma.commission.update({
            where: { commissionId },
            data: updateData,
        });

        if (!updatedCommission) {
            throw new AppError("Commission not found", 404);
        }

        return updatedCommission;
    } catch (err) {
        console.error(err);
        throw new AppError("Error updating commission", 500);
    }
};

export const createArtwork = async (artworkData: { artistId: string; imageUrl: string }) => {
    try {
        const newArtwork = await prisma.artwork.create({
            data: artworkData,
        });

        if (!newArtwork) {
            throw new AppError("Error creating artwork", 500);
        }

        return newArtwork;
    } catch (err) {
        // console.error(err);
        throw new AppError("Failed to create artwork", 500);
    }
};

export const updateArtwork = async (
    artworkId: string,
    updateData: {
        imageUrl?: string;
        customerHide?: boolean;
        artistHide?: boolean;
    }
) => {
    try {
        const updatedArtwork = await prisma.artwork.update({
            where: { artworkId },
            data: updateData,
        });

        if (!updatedArtwork) {
            throw new AppError("Artwork not found", 404);
        }

        return updatedArtwork;
    } catch (err) {
        // console.error(err);
        throw new AppError("Failed to update artwork", 500);
    }
};
