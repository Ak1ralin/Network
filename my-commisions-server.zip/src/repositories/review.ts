import prisma from "../database/prisma"
import { AppError } from "../utils/AppError";

export const createReview = async (reviewData: any) => {
    try {
        const newReview = await prisma.review.create({
            data: reviewData
        })

        if (!newReview) {
            throw new AppError("Error creating review", 500);
        }

        return newReview;

    } catch (err) {
        throw err;
    }
}

export const getReviewById = async (reviewId: string) => {
    try {
        const review = await prisma.review.findUnique({
            where: {
                reviewId: reviewId
            }
        })

        if (!review) {
            throw new AppError("Review not found", 404);
        }

        return review
    } catch (error) {
        throw error;
    }
}

export const getAllReviewsById = async (userId: string) => {
    try {
        
        const reviews = await prisma.review.findMany({
            where: {
                revieweeId: userId
            }
        })
        
        if (!reviews) {
            throw new AppError("No reviews found", 404);
        }

        return reviews;

    } catch (error) {
        throw error;
    }
}

export const deleteReviewById = async (reviewId: string) => {
    try {

        const review = await prisma.review.delete({
            where: {
                reviewId: reviewId
            }
        })

        return review;
    } catch (error) {
        throw error
    }
}