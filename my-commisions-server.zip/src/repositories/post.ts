import prisma from "../database/prisma";
import { AppError } from "../utils/AppError";

export const createPost = async (postData: any) => {
    try {
        const { postTags, ...post } = postData;

        const newPost = await prisma.post.create({
            data: post,
        });

        if (!newPost) {
            throw new AppError("Error creating post", 500);
        }

        const newTags = await prisma.postTag.createMany({
            data: postTags.map((tag: any) => {
                return {
                    postId: newPost.postId,
                    postTag: tag,
                };
            }),
        });

        if (!newTags) {
            throw new AppError("Error assigning tags", 500);
        }

        return { ...newPost, postTags };
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const getPostById = async (postId: string) => {
    try {
        const post = await prisma.post.findUnique({
            where: {
                postId: postId,
            },
            include: {
                postTags: {
                    select: {
                        postTag: true,
                    },
                },
                User: true,
            },
        });

        if (!post) {
            throw new AppError("Post not found", 404);
        }

        return { ...post, postTags: post.postTags.map((tag: any) => tag.postTag) };
    } catch (err) {
        // console.error(err);
        throw err;
    }
};

export const getPostByQuery = async (artistIds: string[], searchQuery: string[], tagQuery: string[]) => {
    try {
        const posts = await prisma.post.findMany({
            where: {
                AND: [
                    // Tag filtering (AND condition for all tags in tagQuery)
                    tagQuery.length > 0
                        ? { 
                            postTags: { 
                                some: { 
                                    postTag: { 
                                        in: tagQuery, 
                                        mode: "insensitive" 
                                    }
                                } 
                            }
                        }
                        : {},

                    // Other conditions (OR for artistIds and searchQuery)
                    {
                        OR: [
                            // Filter by artist IDs
                            artistIds.length > 0
                                ? { artistId: { in: artistIds } }
                                : {},

                            searchQuery.length > 0
                                ? {
                                    OR: searchQuery.map((query) => ({
                                        postDescription: { contains: query, mode: "insensitive" }
                                    }))
                                }
                                : {},
                        ],
                    },
                ],
            },
            include: {
                postTags: {
                    select: {
                        postTag: true
                    }
                },
                User: {
                    select: {
                        userId: true,
                        displayName: true,
                        profileUrl: true,
                        artistRate: true,
                        createdAt: true,
                        updatedAt: true,
                    }
                }
            },
            orderBy: {
                createdAt: "desc", 
            },
        });

        const data = posts.map(post => ({
            ...post,
            postTags: post.postTags.map(tag => tag.postTag)
        }));

        return data;
    } catch (err) {
        throw err;
    }
};



export const editPost = async (postId: string, postData: any) => {
    try {
        // console.log(`postId: ${postId}`);
        // console.log(postData);

        const { postTags, ...post } = postData;
        // console.log(post);

        // prisma.$on('query', (e) => {
        //     console.log(e.query);
        //     console.log('Params: ' + e.params)
        //     console.log('Duration: ' + e.duration + 'ms')

        // });

        const editedPost = await prisma.post.update({
            where: {
                postId,
            },
            data: post,
            include: {
                User: true,
            }
        })

        if (!editedPost) {
            throw new AppError("Post not found", 404);
        }

        if (postTags) {
            const deletedTags = await prisma.postTag.deleteMany({
                where: {
                    postId: postId,
                },
            });
            // console.log(deletedTags)
            const newTags = await prisma.postTag.createMany({
                data: postTags.map((tag: any) => {
                    return {
                        postId,
                        postTag: tag,
                    };
                }),
            });
            // console.log(newTags)
        }

        return await getPostById(postId);
    } catch (err) {
        console.error(err);
        throw new AppError("Error editing post", 500);
    }
};

export const getPostFromUser = async (userId: string) => {
    try {
        const post = await prisma.post.findMany({
            where: {
                artistId: userId,
            },
            include: {
                postTags: true,
                // User: true,
            },
        });

        if (!post) {
            throw new AppError("Post not found", 404);
        }

        return post;
    } catch (err) {
        // console.error(err);
        throw err;
    }
};

export const getRandomPosts = async (numPost = 10) => {
    try {
        const postIds: { postId: string }[] =
            await prisma.$queryRaw`select "postId" from "Post" where "isHide"=false order by random() limit ${numPost}`;
        const posts = await Promise.all(
            postIds.map(async ({ postId }) => {
                return await prisma.post.findUnique({
                    where: {
                        postId: String(postId),
                    },
                    include: {
                        User: true,
                        postTags: true,
                    },
                });
            })
        );

        return posts;
    } catch (err) {
        throw new AppError(`Failed retrieve random posts`, 500);
    }
};

export const hidePost = async (postId: string) => {
    try {
        const post = await prisma.post.findUnique({
            where: {
                postId,
            },
        });

        if (!post) {
            throw new AppError(`Post not found`, 404);
        }

        const toggledPost = await prisma.post.update({
            where: {
                postId,
            },
            data: {
                isHide: !post.isHide,
            },
        });

        return toggledPost;
    } catch (err) {
        throw new AppError(`Failed to toggle hide status post`, 500);
    }
};

// Get boosted posts from a specific user
export const getBoostedPostsFromUser = async (userId: string) => {
    try {
        const posts = await prisma.post.findMany({
            where: {
                artistId: userId,
                boostExpiredDate: {
                    gt: new Date(),
                },
            },
            include: {
                User: true,
                postTags: true,
            },
        });
        return posts;
    } catch (err) {
        throw new AppError("Failed to retrieve boosted posts from user", 500);
    }
};

// Get posts that are currently boosted
export const getBoostedPosts = async () => {
    try {
        const posts = await prisma.post.findMany({
            where: {
                boostExpiredDate: {
                    gt: new Date(),
                },
                isHide: false,
            },
            include: {
                User: true,
                postTags: true,
            },
        });
        return posts;
    } catch (err) {
        throw new AppError("Failed to retrieve boosted posts", 500);
    }
};

// Get posts that are not boosted
export const getNonBoostedPosts = async () => {
    try {
        const posts = await prisma.post.findMany({
            where: {
                boostExpiredDate: {
                    lte: new Date(),
                },
                isHide: false,
            },
            include: {
                User: true,
                postTags: true,
            },
        });
        return posts;
    } catch (err) {
        throw new AppError("Failed to retrieve non-boosted posts", 500);
    }
};

export const getRandomBoostedPosts = async (numPost = 10) => {
    try {
        const postIds: { postId: string }[] =
            await prisma.$queryRaw`select "postId" from "Post" where "isHide"=false and "boostExpiredDate" > now() order by random() limit ${numPost}`;

        const posts = await Promise.all(
            postIds.map(async ({ postId }) => {
                return await prisma.post.findUnique({
                    where: {
                        postId: String(postId),
                    },
                    include: {
                        User: true,
                        postTags: true,
                    },
                });
            })
        );

        return posts;
    } catch (err) {
        throw new AppError("Failed to retrieve random boosted posts", 500);
    }
};

export const getRandomNonBoostedPosts = async (numPost = 10) => {
    try {
        const postIds: { postId: string }[] =
            await prisma.$queryRaw`select "postId" from "Post" where "isHide"=false and "boostExpiredDate" <= now() order by random() limit ${numPost}`;

        const posts = await Promise.all(
            postIds.map(async ({ postId }) => {
                return await prisma.post.findUnique({
                    where: {
                        postId: String(postId),
                    },
                    include: {
                        User: true,
                        postTags: true,
                    },
                });
            })
        );

        return posts;
    } catch (err) {
        throw new AppError("Failed to retrieve random non-boosted posts", 500);
    }
};

// Edit the boost expiration date of a post
export const editPostBoostDate = async (postId: string, newBoostDate: Date) => {
    try {
        const updatedPost = await prisma.post.update({
            where: {
                postId: postId,
            },
            data: {
                boostExpiredDate: newBoostDate,
            },
        });
        return updatedPost;
    } catch (err) {
        throw new AppError("Failed to update post boost date", 500);
    }
};
