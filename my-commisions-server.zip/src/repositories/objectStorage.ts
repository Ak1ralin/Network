import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { AppError } from "../utils/AppError";
import dotenv from "dotenv";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

dotenv.config();

const s3 = new S3Client({
    region: process.env.REGION!,
    endpoint: process.env.STORAGE_ENDPOINT!,
    credentials: {
        accessKeyId: process.env.ACCESS_KEY!,
        secretAccessKey: process.env.SECRET_ACCESS_KEY!,
    },
});

interface uploadImageArgs {
    filename: string;
    picture: any;
    contentType: any;
    folder: string;
}

export const uploadImage = async ({ filename, picture, contentType, folder }: uploadImageArgs) => {
    if (!picture) {
        throw new AppError("Image is not provided", 400);
    }

    try {
        const params = {
            Bucket: process.env.BUCKET_NAME!,
            Key: `${folder}/${filename}`,
            Body: picture,
            ContentType: contentType,
        };

        const command = new PutObjectCommand(params as any);
        await s3.send(command);

        return {
            savedFilename: filename,
        };
    } catch (err) {
        console.error(err);
        throw new AppError("Error uploading image", 500);
    }
};

export const getPreSignedUrl = async (filename: string) => {
    const command = new GetObjectCommand({
        Bucket: process.env.BUCKET_NAME!,
        Key: filename,
    });

    const signedUrl = await getSignedUrl(s3, command, { expiresIn: 3600 });
    return signedUrl;
};

export const getUploadPreSignedUrl = async (filename: string, fileType: string) => {
    const command = new PutObjectCommand({
        Bucket: process.env.BUCKET_NAME!,
        ContentType: fileType,
        Key: filename,
    });

    const signedUrl = await getSignedUrl(s3, command, { expiresIn: 360 });
    return signedUrl;
};
