import prisma from "../database/prisma";

export const createArtwork = async ({ artistId, artworkPath }: { artistId: string; artworkPath: string }) => {
    try {
        
        const artwork = await prisma.artwork.create({
            data: {
                artistId: artistId,
                imageUrl: artworkPath,
            }
        });

        return { artwork };

    } catch (err) {
        throw err;
    }
}