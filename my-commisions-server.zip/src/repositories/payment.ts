import prisma from "../database/prisma";
import { AppError } from "../utils/AppError";

export const addCreditCard = async (data: any) => {

    try {

        const creditCard = await prisma.creditCard.create({
            data: data
        })

        if (!creditCard) {
            throw new AppError("Error adding credit card", 500);
        }

        return creditCard;

    } catch (err) {
        throw err;
    }

}

export const getCreditCard = async (userId: string) => {

    try {

        const creditCard = await prisma.creditCard.findUnique({
            where: {
                userId: userId,
            }
        })

        if (!creditCard) {
            throw new AppError("Credit card not found", 404);
        }

        return creditCard;

    } catch (err) {
        throw err;
    }
}

export const editCreditCard = async (data: any) => {

    try {

        const editedCreditCard = await prisma.creditCard.update({
            where: {
                userId: data.userId,
            },
            data: data
        })

        if (!editedCreditCard) {
            throw new AppError("Error editing credit card", 404);
        }

        return editedCreditCard;

    } catch (err) {
        throw new AppError("Error editing post", 500);
    }
}

export const createPaymentTransaction = async ({
    customerId,
    artistId,
    paymentMethod,
    commissionId,
    stripeId,
    amount
}: {
    customerId: string,
    artistId: string,
    paymentMethod: any,
    commissionId: any,
    stripeId?: string,
    amount: number
}) => {
    const newPaymentTransaction = await prisma.paymentTransaction.create({
        data: {
            customerId,
            artistId,
            paymentMethod,
            commissionId,
            stripeId,
            amount
        },
    });

    return newPaymentTransaction
}

export const createPostBoostTransaction = async ({
    expiredDate,
    amount,
    count,
    posts
}: {
    expiredDate: Date,
    amount: number,
    count: number,
    posts: string[]
}) => {

    try {
        const newPostBoostTxn = await prisma.postBoostTransaction.create({
            data: {
                expiredDate,
                amount,
                count,
                posts: {
                    connect: posts.map((postId) => ({ postId }))
                }
            }, include: {
                posts: true,
            },
        })

        return newPostBoostTxn
    } catch (error) {
        console.log(error)
    }



}