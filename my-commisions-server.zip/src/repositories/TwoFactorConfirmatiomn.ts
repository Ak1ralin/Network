import prisma from "../database/prisma"

export const getTwoFactorConfirmationByUserIdRepo = async (
    userId: string
) => {

    try {

        const res = await prisma.twoFactorConfirmation.findUnique({
            where: {
                userId: userId
            }
        })

        return res

    } catch (error) {
        throw error
    }

}