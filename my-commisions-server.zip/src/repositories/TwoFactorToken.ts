import prisma from "../database/prisma";

export const getTwoFactorTokenByTokenRepo = async (
    token: string
) => {

    try {
        const res = await prisma.twoFactorToken.findUnique({
            where: {
                token: token
            }
        });

        return res;
        
    } catch (error) {
        throw error;
    }

}

export const getTwoFactorTokenByEmailRepo = async (
    email: string
) => {

    try {

        const res = await prisma.twoFactorToken.findFirst({
            where: {
                email: email
            },
            orderBy: {
                expires: "desc",
            }
        })

        return res;

    } catch (error) {
        throw error;
    }

}