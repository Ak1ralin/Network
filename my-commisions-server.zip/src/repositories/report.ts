import prisma from "../database/prisma";
import { AppError } from "../utils/AppError";

// Create a new report
export const createReport = async (reportData: any) => {
    try {
        const newReport = await prisma.report.create({
            data: reportData,
        });

        if (!newReport) {
            throw new AppError("Error creating report", 500);
        }

        return newReport;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

// Get a report by ID
export const getReportById = async (reportId: string) => {
    try {
        const report = await prisma.report.findUnique({
            where: { reportId: reportId },
        });

        if (!report) {
            throw new AppError("Report not found", 404);
        }

        return report;
    } catch (err) {
        throw err;
    }
};

// Get all reports made by a specific user
export const getReportsByUser = async (userId: string) => {
    try {
        const reports = await prisma.report.findMany({
            where: { reporterId: userId },
        });

        if (!reports.length) {
            throw new AppError("No reports found", 404);
        }

        return reports;
    } catch (err) {
        throw err;
    }
};

// Update a report by ID
export const updateReportById = async (reportId: string, updateData: any) => {
    try {
        const updatedReport = await prisma.report.update({
            where: { reportId: reportId },
            data: updateData,
        });

        if (!updatedReport) {
            throw new AppError("Report not found", 404);
        }

        return updatedReport;
    } catch (err) {
        console.error(err);
        throw new AppError("Error updating report", 500);
    }
};

// Delete a report by ID
export const deleteReportById = async (reportId: string) => {
    try {
        const deletedReport = await prisma.report.delete({
            where: { reportId: reportId },
        });

        if (!deletedReport) {
            throw new AppError("Report not found", 404);
        }

        return deletedReport;
    } catch (err) {
        throw new AppError("Failed to delete report", 500);
    }
};
