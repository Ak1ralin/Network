import prisma from "../database/prisma";

export const getAdminByEmail = async (email: string) => {
    // return await prisma.admin.findFirst({
    //     where: {
    //         email,
    //     },
    // });
};