import prisma from "../database/prisma";
import { AppError } from "../utils/AppError";

export const getUserByEmail = async (email: string, takePassword = false) => {

    try {

        const foundUser = await prisma.user.findUnique({
            where: {
                email,
            },
        })

        if (!foundUser) throw new AppError("User not found", 404);

        if (takePassword) {
            return foundUser;
        }

        const { password, ...userResponse } = foundUser;

        return userResponse;
        
    } catch (err) {
        throw err;
    }
}

export const getUserById = async (userId: string, takePassword = false) => {

    try {

        const foundUser = await prisma.user.findUnique({
            where: {
                userId,
            }
        });

        if (!foundUser) {
            throw new AppError("User not found", 404);
        }

        if (takePassword) {
            return foundUser;
        }

        const { password, ...userResponse } = foundUser;

        return userResponse;
    } catch (err) {
        throw err;
    }
}

export const getSuggestedArtistsRepo = async (amount: number) => {
    try {

        const artists = await prisma.user.findMany({ take: amount, orderBy: { artistRate: "desc" }});
        return artists.map(artist => {
            const { password, ...rest } = artist;
            return rest;
        });
        
    } catch (err) {
        throw err;
    }
}

export const createUser = async (user: any) => {

    try {

        const newUser = await prisma.user.create({
            data: {
                ...user,
            }
        })

        const { password, ...userResposne } = newUser;

        return userResposne;

    } catch (err) {
        throw err;
    }

}

export const changeUserPassword = async (userId: string, newPassword: string) => {

    try {

        const updatedUser = await prisma.user.update({
            where: {
                userId,
            },
            data: {
                password: newPassword,
            }
        })

        if (!updatedUser) {
            throw new AppError("User not found", 404);
        }

        const { password, ...userResposne } = updatedUser;

        return userResposne;

    } catch (err) {
        throw err;
    }
}

export const updateUserById = async (userId: string, payload: any) => {


    try {

        if (payload.birthDate) {
            payload.birthDate = new Date(payload.birthDate);
        }

        const updatedUser = await prisma.user.update({
            where: {   
                userId,
            },
            data: {
                ...payload,
            }
        })

        if (!updatedUser) {
            throw new AppError("User not found", 404);
        }

        return updatedUser;

    } catch (err) {
        throw err;
    }

}

export const getUserByDisplayName = async (displayNames: string[]) => {
    try {
        let users = await prisma.user.findMany({
            where: {
                OR: displayNames.map(name => ({
                    displayName: {
                        contains: name,
                        mode: "insensitive"
                    }
                }))
            }
        });

        const mappedUsers = users.map(user => ({
            userId: user.userId,
            displayName: user.displayName,
            profileUrl: user.profileUrl,
            artistFlag: user.artistFlag,
            artistRate: user.artistRate
        }));
        
        return mappedUsers;
    } catch (err) {
        throw err;
    }
};
