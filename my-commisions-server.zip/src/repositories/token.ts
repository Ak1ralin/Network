import crypto from 'crypto'
import { getTwoFactorTokenByEmailRepo } from './TwoFactorToken'
import prisma from '../database/prisma'
import { v4 as uuidv4 } from 'uuid'
import { getPasswordResetTokenByEmailRepo } from './PasswordReset'

export const generateTwoFactorToken = async (
    email: string
) => {

    const token = crypto.randomInt(1e5, 1e6).toString()
    const expires = new Date(new Date().getTime() + 900 * 1000)
    const existingToken = await getTwoFactorTokenByEmailRepo(email)

    if (existingToken) {
        await prisma.twoFactorToken.delete({
            where: {
                id: existingToken.id
            }
        })
    }

    const twoFactorToken = await prisma.twoFactorToken.create({
        data: {
            token: token,
            email: email,
            expires: expires,

        }
    })

    return twoFactorToken
}

export const generatePasswordResetToken = async (email: string) => {
    
    const token = uuidv4()
    const expires = new Date(new Date().getTime() + 3600 * 1000)

    const existingToken = await getPasswordResetTokenByEmailRepo(email);

    if (existingToken) {
        await prisma.passwordResetToken.delete({
            where: {
                id: existingToken.id
            }
        })
    }

    const passwordResetToken = prisma.passwordResetToken.create({
        data: {
            email: email,
            token: token,
            expires: expires
        }
    })

    return passwordResetToken;
}

export const deletePasswordResetToken = async (
    id: string
) => {
    const deletedToken = await prisma.passwordResetToken.delete({
        where: {
            id: id
        }
    })

    return deletedToken
}

export const deleteTwoFactorToken = async(
    token:string
) =>{

    try {
        const deletedToken = await prisma.twoFactorToken.delete({
            where: {
                token:token
            }
        }) 

        return deletedToken
    } catch (error) {
        throw error;
    }
   
}