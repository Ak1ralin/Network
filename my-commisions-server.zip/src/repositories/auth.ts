import prisma from "../database/prisma";

export const createUser = async (user: any) => {
    
    try {
        const newUser = await prisma.user.create({
            data: {
                ...user,
                birthDate: new Date(`${user.birthDate}T00:00:00.000Z`),
            }
        })

        const { password, ...userResponse } = newUser;

        return userResponse;

    } catch (err) {
        throw new Error("Error creating user");
    }

}

export const getUserWithPassword = async (email: string) => {

    try {

        const foundUser = await prisma.user.findUnique({
            where: {
                email,
            }
        })

        return foundUser;
    } catch (err) {
        throw err;
    }
}

