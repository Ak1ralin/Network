import prisma from "../database/prisma";
import { AppError } from "../utils/AppError";

export const getChatroomByUserId = async (userId: string) => {
    try {
        let chatRooms = await prisma.chatRoom.findMany({
            where: {
                users: {
                    some: {
                        userId: userId,
                    },
                },
            },
            include: {
                users: {
                    select: {
                        userId: true,
                        displayName: true,
                    },
                },
                commissions: true,
                messages: true,
            },
        });
    
        return chatRooms.map((chatRoom) => {
            const { messages, ...chatRoomNoMsg } = chatRoom;
            const latestCommission = chatRoom.commissions.sort((a: any, b: any) => b.createdAt.getTime() - a.createdAt.getTime()).at(0) || null;
            const lastMessage = chatRoom.messages.sort((a: any, b: any) => b.createdAt.getTime() - a.createdAt.getTime()).at(0) || null;
            return {
                ...chatRoomNoMsg,
                latestCommission,
                lastTimeStamp: lastMessage ? lastMessage.createdAt : chatRoom.createdAt,
                latestMessage: lastMessage ? lastMessage.content : `Start your chat`,
                latestMessageType: lastMessage ? lastMessage.messageType : "NONE",
            }
        });
    } catch (error) {
        console.error(error);
        throw new AppError("Failed to get chatrooms", 500);
    }
};

export const checkHasChatbyUserId = async (userId1: string, userId2: string) => {
    let chatroom = await prisma.chatRoom.findMany({
        where: {
            users: {
                every: {
                    OR: [{ userId: userId1 }, { userId: userId2 }],
                },
            },
        },
        include: {
            users: {
                select: {
                    userId: true,
                    displayName: true,
                },
            },
        },
    });

    return chatroom;
};

export const getChatroomById = async (chatRoomId: string) => {
    try {
        const chatroom = await prisma.chatRoom.findUnique({
            where: { chatRoomId },
            include: {
                users: {
                    select: {
                        userId: true,
                    }
                },
                commissions: true
            },
        });
    
        return chatroom;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const getMessageByChatId = async (chatRoomId: string) => {
    let chatroom = await prisma.chatRoom.findUnique({
        where: {
            chatRoomId: chatRoomId,
        },
        include: {
            messages: {
                orderBy: {
                    createdAt: "asc",
                },
            },
            commissions: true,
        },
    });

    return chatroom;
};

export const createChatroom = async (creatorId: string, memberId: string) => {
    try {

        const newChatroom = await prisma.chatRoom.create({
            data: {
                users: {
                    connect: [{ userId: creatorId }, { userId: memberId }],
                },
            },
        });
    
        return newChatroom;
    } catch (error) {
        throw new AppError(`Error creating chat room`, 500);
    }
};

export const setChatroomCommission = async (chatRoomId: string, commissionId: string) => {
    const chatroom = await prisma.chatRoom.update({
        where: {
            chatRoomId,
        },
        data: {
            commissions: { connect: { commissionId } },
        },
    });

    return chatroom;
};

export const createMessage = async ({
    chatRoomId,
    senderId,
    content,
    messageType,
}: {
    chatRoomId: string;
    senderId: string;
    content: string;
    messageType: any;
}) => {

    try {
        const newMessage = await prisma.message.create({
            data: {
                sender: {
                    connect: {
                        userId: senderId,
                    },
                },
                chatRoom: {
                    connect: {
                        chatRoomId: chatRoomId,
                    },
                },
                content,
                messageType,
            },
        });
    
        return newMessage;
    } catch (error) {
        console.error(error);
        throw new AppError(`Failed to create message`, 500);
    }
};
