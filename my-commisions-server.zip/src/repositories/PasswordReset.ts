import prisma from "../database/prisma";

export const getPasswordResetTokenByTokenRepo = async (
    token: string
) => {
    try {
        
        const passwordResetToken = await prisma.passwordResetToken.findUnique({
            where: {
                token: token
            }
        })

        return passwordResetToken;

    } catch (error) {
        throw error;
    }
}

export const getPasswordResetTokenByEmailRepo = async (
    email: string
) => {
    try {
        const passwordResetToken = await prisma.passwordResetToken.findFirst({
            where: {
                email: email
            }
        })

        return passwordResetToken;

    } catch (error) {
        throw error;
    }
}