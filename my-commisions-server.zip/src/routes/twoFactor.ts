import { Router } from "express";
import {
    resetForgotPassword,
    sendPasswordResetToken
} from "../controllers/PasswordReset";

const router = Router();

/* forget password */
router.post("/reset-password", sendPasswordResetToken); /* request token and send path for reset password */
router.post("/new-password/:token", resetForgotPassword); /* update password after reset using /reset-passwprd */

export default router;