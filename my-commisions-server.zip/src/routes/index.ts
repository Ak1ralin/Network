import { Router } from "express";

/* services' routers */
import authRouter from "./auth";
import userRouter from "./user";
import postRouter from "./post";
import commissionRouter from "./commission";
import twoFactorRouter from "./twoFactor";
import paymentRouter from "./payment";
import reviewRouter from "./review";
import reportRouter from "./report";
import chatRouter from "./chat";
import adminRouter from "./admin"

/* middlewares */
import { authorizeAdmin, verifyToken } from "../middlewares/auth";
import { errorHandler } from "../middlewares/error";

const router = Router();

router.use("/auth", authRouter);
router.use("/forget-password", twoFactorRouter);

router.use("/user", verifyToken, userRouter);
router.use("/post", verifyToken, postRouter);
router.use("/commission", verifyToken, commissionRouter);
router.use("/payment", verifyToken, paymentRouter);
router.use("/review", verifyToken, reviewRouter);
router.use("/report", verifyToken, reportRouter);
router.use("/chat", verifyToken, chatRouter);
router.use("/twoFactor", authorizeAdmin, adminRouter);

router.use(errorHandler);

export default router;
