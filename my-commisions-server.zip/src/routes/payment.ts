import { Router } from "express";
import {
    addCreditCard, getCreditCard, editCreditCard,
    createPaymentIntent, createQRPayment,
    createPaymentTransaction, createPostBoostTransaction
} from "../controllers/payment";
import { itemsValidator } from "../validators/item";

const router = Router()

/* add payment info */
router.post("/credit-card/add", addCreditCard);
router.get("/credit-card/", getCreditCard);
router.patch("/credit-card/edit", editCreditCard);

/* mock payment */
router.post("/stripe/create-payment-intent", createPaymentIntent)
router.post("/promptpay/create-qr", createQRPayment)
router.post("/create-payment-transaction", createPaymentTransaction)
router.post("/create-post-boost-transaction", createPostBoostTransaction)

export default router