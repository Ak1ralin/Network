import { Router } from "express";
import { getReview, getReviewsOfUser, createReview, deleteReview } from "../controllers/review";
import { createReviewValidator } from "../validators/review";

const router = Router();

router.get("/:reviewId", getReview).delete("/:reviewId", deleteReview); // Get a single review
router.get("/user/:userId", getReviewsOfUser); // Get all reviews by a user
router.post("/create", createReviewValidator, createReview); // Create a review

export default router;