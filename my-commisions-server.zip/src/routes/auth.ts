import { Router } from "express";
import { check2FA, login, logout, register, sendEmail } from "../controllers/auth";
import {
    registerValidator,
    loginValidator,
} from "../validators/auth"

const router = Router();

router.post("/register", registerValidator, register);
router.post("/login", loginValidator, login);
router.post("/two-factor-enable", check2FA);
router.post("/send-email", sendEmail);
router.post("/logout", logout);

export default router;