import { Router } from "express";
import {
    submitReport,
    getReport,
    getReportHistory,
    getReportAdmin,
    getAllReportFromUserAdmin,
    editReportAdmin,
} from "../controllers/report";
import { createReportValidator, editReportValidator } from "../validators/report";

const router = Router();

router.post("/submit", createReportValidator, submitReport);
router.get("/:reportId", getReport);
router.get("/history", getReportHistory);

// Admin routes
router.get("/admin/get/:reportId", getReportAdmin);
router.get("/admin/get/from/:userId", getAllReportFromUserAdmin);
router.patch("/admin/edit/:reportId", editReportValidator, editReportAdmin);

export default router;
