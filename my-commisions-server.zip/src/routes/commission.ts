import { Router } from "express";
import {
    createCommissionValidator,
    sendBriefValidator,
    sendProposalValidator,
    sendArtworkValidator,
    editCommissionValidator,
    commissionIdValidator,
} from "../validators/commission";
import {
    acceptBrief,
    createCommission,
    acceptProposal,
    getCommissionById,
    editBrief,
    rejectBrief,
    uploadArtwork,
    sendArtwork,
    acceptArtwork,
    getArtworksFromUser,
} from "../controllers/commission";

const router = Router();

/* commission info */
router.get("/:commissionId", commissionIdValidator, getCommissionById);

/* commission lifecycle */
router.post("/create", createCommissionValidator, createCommission);
router.patch("/brief/accept/:commissionId", commissionIdValidator, sendProposalValidator, acceptBrief); /* breif -> proposal */
router.patch("/brief/edit/:commissionId", commissionIdValidator, editBrief);
router.patch("brief/reject/:commissionId", commissionIdValidator, rejectBrief);
router.patch("/proposal/accept/:commissionId", commissionIdValidator, acceptProposal);
router.get("/artwork/upload/url/:commissionId", commissionIdValidator, uploadArtwork);
router.patch("/artwork/send/:commissionId", commissionIdValidator, sendArtwork);
router.patch("/artwork/accept/:commissionId", commissionIdValidator, acceptArtwork);
router.get("/artwork/from/:userId", getArtworksFromUser);

export default router;
