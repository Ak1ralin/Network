import { Router } from "express";
import { changePassword, enable2FA, getUserProfile, updateUser, uploadProfilePicture, searchUser, getSuggestedArtists } from "../controllers/user";
import { userIdParamValidator, updateUserValidator, changePasswordValidator } from "../validators/user";

const router = Router();

router.get("/", searchUser)
router.get("/profile/:userId", userIdParamValidator, getUserProfile);
router.get("/top-artists/:amount", getSuggestedArtists);
router.post("/enable-2fa/:userId", enable2FA);
router.patch("/change-password/:userId", changePasswordValidator, changePassword);
router.patch("/account/:userId", userIdParamValidator, updateUserValidator, updateUser);
router.patch("/account/profile-pic/:userId", userIdParamValidator, uploadProfilePicture)

export default router;