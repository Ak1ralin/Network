import { Router } from "express";
import { createChatroom, createMessage, getUserChatroom, getChatroomInformation, getMessageChatroom } from "../controllers/chat";

const router = Router();

router.get('/chatroom/:userId', getUserChatroom)
router.get('/chatroom/get/:chatRoomId', getChatroomInformation)
router.get('/message-chatroom/:chatroomId', getMessageChatroom)
router.post('/message', createMessage)
router.post('/chatroom', createChatroom)

export default router