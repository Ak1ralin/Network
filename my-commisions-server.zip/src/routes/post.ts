import { Router } from "express";
import {
    createPost,
    getPost,
    editPost,
    getAllPostFromUser,
    updatePostImages,
    getFeedPosts, searchPosts,
    getBoostedPostsFromUser,
    getAllBoostedPosts,
    getAllNonBoostedPosts,
    getRandomBoostedPosts,
    getRandomNonBoostedPosts,
    cancelPostBoost,
} from "../controllers/post";
import { createPostValidator, editPostValidator } from "../validators/post";

const router = Router();

router.get("/", searchPosts)
router.get("/:postId", getPost);
router.get("/from/:userId", getAllPostFromUser);
router.get("/random/feed", getFeedPosts);
router.post("/create", createPostValidator, createPost);
router.patch("/:postId", editPostValidator, editPost);
router.patch("/upload/:postId", updatePostImages);
// router.patch("/hide")
router.get("/boost/from/:userId", getBoostedPostsFromUser);
router.get("/get/boost", getAllBoostedPosts);
router.get("/get/non-boost", getAllNonBoostedPosts);
router.get("/random/boost", getRandomBoostedPosts);
router.get("/random/non-boost", getRandomNonBoostedPosts);
router.patch("/cancel-boost/:postId", cancelPostBoost);

export default router;
