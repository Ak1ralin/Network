import { Router } from "express";
import {
    loginAdmin,
    logoutAdmin,
    getAllUsers,
    getReportedCommission,
    getReportedPosts,
    banUser,
    unbanUser
} from "../controllers/admin";

const router = Router();

router.post("/login", loginAdmin);
router.post("/logout", logoutAdmin);
router.get("/users", getAllUsers);
router.get("/commissions", getReportedCommission);
router.get("/posts", getReportedPosts);
router.patch("/ban/:userId", banUser);
router.patch("/unban/:userId", unbanUser);

export default router;