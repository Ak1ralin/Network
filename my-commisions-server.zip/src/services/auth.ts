import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { config } from "dotenv";
import { createUser } from "../repositories/auth";
import { getUserByEmail, getUserById } from "../repositories/user";
import { getUserWithPassword } from "../repositories/auth";
import { deleteTwoFactorToken, generateTwoFactorToken } from "../repositories/token";
import { sendTwoFactorEmail } from "./mail";
import { getTwoFactorTokenByEmailRepo } from "../repositories/TwoFactorToken";
import { AppError } from "../utils/AppError";
import { string } from "zod";
import { getPreSignedUrl } from "../repositories/objectStorage";

config();

export const registerService = async (user: any) => {

    try {
        const { password } = user;
        const hashedPassword = await bcrypt.hash(password, 6);

        const userInfo = {
            ...user,
            password: hashedPassword,
        }

        const createdUser = await createUser(userInfo);
        const token = jwt.sign({ id: createdUser.userId }, process.env.JWT_SECRET!, { expiresIn: "2d" });

        return {
            user: createdUser,
            token,
        }

    } catch (error) {
        throw error
    }


}

export const login2FA = async ({
    email,
    password,
}: {
    email: string,
    password: string,
}) => {

    const user = await getUserWithPassword(email);

    if (!user) {
        throw new AppError("Wrong email or password", 404);
    }

    const encryptedPassword = user.password;
    const isMatched = await bcrypt.compare(password, encryptedPassword);

    if (!isMatched) {
        throw new AppError("Wrong email or password", 401);
    }

    if (user.enabled2FA) { /* user enable 2FA */

        /* check existing token */
        const twoFaToken = await generateTwoFactorToken(email);
        /* @ts-ignore */
        const { error } = await sendTwoFactorEmail(email, twoFaToken.token);

        if (error) {
            throw new AppError("Server failed to send email", 500);
        }

        return {
            statusCode: 200,
            message: "two-factor authentication token sent to email",
        }

    } else { /* normal login */

        const token = jwt.sign({ id: user.userId }, process.env.JWT_SECRET!);
        const { password, profileUrl, ...userResponse } = user;

        return {
            statusCode: 200,
            message: "login complete",
            user: {
                ...user,
                profileUrl: profileUrl ? await getPreSignedUrl(profileUrl) : null,
            },
            token,
        }

    }

}

export const check2FAService = async ({
    email,
    token
}: {
    email: string,
    token: string
}) => {

    try {

        const twoFactorToken = await getTwoFactorTokenByEmailRepo(email);

        if (!twoFactorToken) throw new AppError("Token not found!", 404);

        const hasExpired = new Date(twoFactorToken.expires) < new Date();

        if (hasExpired) throw new AppError("Token Expired!", 400);
        if (token !== twoFactorToken.token) throw new AppError("Token Invalid!", 401);

        /* After check token */
        await deleteTwoFactorToken(token);
        const user = await getUserByEmail(email);
        const authToken = jwt.sign({ id: user!.userId }, process.env.JWT_SECRET!);

        return {
            user,
            authToken: authToken,
        }

    } catch (err) {
        console.log(err)
        throw err;
    }

}

export const verifyEmail = async ({
    userId,
}: {
    userId: string;
}) => {

    try {

        const { email } = await getUserById(userId);
        const twoFaToken = await generateTwoFactorToken(email);
        /* @ts-ignore */
        await sendTwoFactorEmail(email, twoFaToken.token);

        return {
            statusCode: 200,
            message: "two-factor authentication token sent to email",
        }
    } catch (err) {
        throw err;
    }

}