import { generatePasswordResetToken } from "../repositories/token";
import { sendPasswordResetEmail } from "../services/mail";
import { getUserByEmail } from "../repositories/user";

export const resetPassword = async (email: string, pageRoute: string) => {

    const existingUser = await getUserByEmail(email);

    if (!existingUser) {
        return { success: 0 };
    }

    //Generate Token & sent email
    const passwordResetToken = await generatePasswordResetToken(email)
    const mail = await sendPasswordResetEmail(passwordResetToken.email, passwordResetToken.token, pageRoute);

    return { success:1, passwordResetToken , mail }

}