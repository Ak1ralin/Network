import { addCreditCard, getCreditCard, editCreditCard, createPaymentTransaction, createPostBoostTransaction } from "../repositories/payment";
import { editPostBoostDate } from "../repositories/post";
import { AppError } from "../utils/AppError";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: "2025-01-27.acacia",
});

export const addCreditCardService = async (body: any) => {

    try {

        const data = {
            userId: body.user.id,
            ...body
        };

        delete data.user

        const post = await addCreditCard(data);

        return post

    } catch (error) {
        throw error
    }

}

export const getCreditCardService = async (userId: string) => {

    try {

        const creditCard = await getCreditCard(userId);

        if (!creditCard) {
            throw new AppError("Credit card not found", 404);
        }
        return creditCard;

    } catch (err) {
        throw err;
    }

}

export const editCreditCardService = async (body: any) => {

    try {

        const data = {
            userId: body.user.id,
            ...body
        };

        delete data.user

        const creditCard = await editCreditCard(data);

        return creditCard;

    } catch (err) {
        throw err;
    }

}

export const createPaymentIntentService = async (amount: number, currency: string) => {

    // console.log(`Amount: ${amount}`);
    const paymentIntent = await stripe.paymentIntents.create({
        amount: amount * 100,
        currency,
        payment_method_types: ["card"],
    });

    return paymentIntent;
};

export const createPaymentTransactionService = async ({
    customerId,
    artistId,
    paymentMethod,
    commissionId,
    stripeId,
    amount
}: {
    customerId: string,
    artistId: string,
    paymentMethod: any,
    commissionId: any,
    stripeId?: string,
    amount: number
}) => {
    try {
        const { transactionId } = await createPaymentTransaction({ customerId, artistId, paymentMethod, commissionId, stripeId, amount });
        return transactionId;
    } catch (error) {
        console.error(error)
        throw new AppError("Error Create payment transaction", 500);
    }
}

export const createPostBoostTransactionService = async ({
    expiredDate,
    amount,
    count,
    posts
}: {
    expiredDate: Date,
    amount: number,
    count: number,
    posts: string[]
}) => {

    try {
        const newPostBoostTxn = await createPostBoostTransaction({ expiredDate, amount, count, posts });

        const boostedPost = await Promise.all(
            posts.map((postId) => editPostBoostDate(postId, expiredDate))
        )

        return { newPostBoostTxn, boostedPost };

    } catch (error) {
        console.log(error)
        throw new AppError("Cannot create Post Boost Transaction", 500)
    }
}