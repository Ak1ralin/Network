import { createReview, getReviewById, getAllReviewsById, deleteReviewById } from "../repositories/review";
import { updateUserInfo } from "./user";
import { AppError } from "../utils/AppError";

export const createReviewService = async (body: any) => {
    try {

        const review = await createReview(body);

        const allReviews = await getReviewsOfUserService(review.revieweeId)
        let artistRate = allReviews.length ? allReviews.reduce((sum, e) => sum + e.rating, 0) / allReviews.length : 0;
        const payload = { artistRate };
        await updateUserInfo(review.revieweeId, payload);

        return review;

    } catch (err) {
        throw err;
    }
}

export const getReviewService = async (reviewId: string) => {
    try {

        const review = await getReviewById(reviewId);

        if (!review) {
            throw new AppError("Review not found", 404);
        }

        return review;

    } catch (error) {
        throw error;
    }
}

export const getReviewsOfUserService = async (userId: string) => {
    try {

        const reviews = await getAllReviewsById(userId);

        if (!reviews) {
            throw new AppError("Reviews not found", 404);
        }

        return reviews;

    } catch (error) {
        throw error;
    }
}

export const deleteReviewService = async (reviewId: string) => {
    try {

        const review = await deleteReviewById(reviewId)
        return review

    } catch (error) {
        throw error
    }

}