import { AppError } from "../utils/AppError";
import {
    createCommission,
    getCommissionById,
    getCommissionsByUser,
    updateCommission,
    createArtwork,
    updateArtwork,
    getArtworksByUser,
} from "../repositories/commission";
import { getPreSignedUrl, getUploadPreSignedUrl, uploadImage } from "../repositories/objectStorage";
import { setChatroomCommission } from "../repositories/chat";
import { getUserProfileService } from "./user";


/* ------------------------------- commission info ----------------------- */
export const getCommissionByIdService = async (commissionId: string) => {
    try {

        const commission = await getCommissionById(commissionId);

        if (!commission) {
            throw new AppError("Commission not found", 404);
        }

        return commission;

    } catch (err) {
        throw err;
    }
}

/* -------------------------------lifecycle------------------------------- */
export const createCommissionService = async (commissionDetails: any) => {
    try {

        const commission = await createCommission({
            ...commissionDetails,
            state: "BRIEF",
        });
        // await 

        return commission;

    } catch (error) {
        throw error;
    }
}

export const changeBriefToProposal = async (commissionId: string, updateInfo: any) => {
    try {

        const commission = await updateCommission(commissionId, {
            ...updateInfo,
            state: "PROPOSAL",
            expectedDate: new Date(updateInfo.expectedDate),
        })

        return { commission };

    } catch (err) {
        throw err;
    }
}

export const rejectBriefService = async (commissionId: string) => {
    try {

        const commission = await updateCommission(commissionId, {
            state: "BRIEF_REJECTED",
        });

        return { commission };
        
    } catch (err) {
        throw err;
    }
}

export const editBriefService = async (commissionId: string, updateInfo: any) => {
    try {

        const commission = await updateCommission(commissionId, {
            ...updateInfo,
            state: "BRIEF",
            deadline: new Date(updateInfo.deadline),
        });

        return { commission };

    } catch (err) {
        throw err;
    }
};

export const changeProposalToWorking = async (commissionId: string, updateInfo: any) => {
    try {
        const commission = await updateCommission(commissionId, {
            ...updateInfo,
            state: "WORKING",
        })
        
        return { commission };

    } catch (err) {
        // console.log(err);
        throw err;
    }
}

export const uploadArtworkService = async (commissionId: string, fileType: string) => {
    try {
        const artWorkKey = `artworks/artwork-${commissionId}}`;
        const uploadUrl = await getUploadPreSignedUrl(artWorkKey, fileType);
        return {
            uploadUrl,
            artworkPath: artWorkKey,
        };
    } catch (err) {
        throw err;
    }
}

export const changeWorkingToShipped = async (commissionId: string, updateInfo: any) => {
    try {

        const { artistId, artworkPath } = updateInfo;
        const artwork = await createArtwork({ artistId, imageUrl: artworkPath });

        const commission = await updateCommission(commissionId, {
            state: "ARTWORK_SHIPPED",
            artworkId: artwork.artworkId,
        });

        return { commission, imageUrl: await getPreSignedUrl(artwork.imageUrl), artworkPath };
        
    } catch (err) {
        throw err;
    }
}

export const finishCommission = async (commissionId: string) => {
    try {
       const commission = await updateCommission(commissionId, {
            state: "FINISHED",
        });

        return { commission };
    } catch (err) {
        throw err;
    }
}

export const getArtworksByUserService = async (requestUserId: string, targetUserId: string) => {
    try {
        const artworks = await getArtworksByUser(targetUserId);

        if (!artworks) {
            throw new AppError("Artworks not found", 404);
        }

        const filteredArtworks = artworks
            .filter((artwork: any) => !((artwork.customerHide || artwork.artistHide) && requestUserId !== artwork.artistId));

        /* @ts-ignore */
        const artworksWithImages = await Promise.all(
            filteredArtworks.map(async (artwork) => {
                return {
                    ...artwork,
                    imageUrl: artwork.imageUrl ? await getPreSignedUrl(artwork.imageUrl) : null,
                };
            })
        );

        const user = await getUserProfileService(targetUserId);

        return {
            artworks: artworksWithImages,
            artist: user,
        };
    } catch (err) {
        throw err;
    }
}