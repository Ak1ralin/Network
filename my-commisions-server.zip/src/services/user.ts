import bcrypt from "bcrypt";
import { changeUserPassword, getUserById, updateUserById, getUserByDisplayName, getSuggestedArtistsRepo } from "../repositories/user";
import { getPreSignedUrl, uploadImage } from "../repositories/objectStorage";
import { getUserWithPassword } from "../repositories/auth";
import { AppError } from "../utils/AppError";

interface UserPassword {
    userId: string;
    oldPassword: string;
    newPassword: string;
}

export const forgetPasswordService = async ({
    userId,
    password,
}: {
    userId: string;
    password: string;
}) => {

    try {

        const hashedPassword = await bcrypt.hash(password, 6);
        const updatedUser = await changeUserPassword(userId, hashedPassword);

        return updatedUser;

    } catch (err) {
        throw err;
    }
}

export const updatePasswordService = async ({
    userId,
    oldPassword,
    newPassword
}: UserPassword) => {

    try {

        const user = await getUserById(userId, true);

        /* @ts-ignore */
        const isMatched = await bcrypt.compare(oldPassword, user.password);

        if (!isMatched) {
            throw new AppError("Wrong password", 401);
        }

        const hashedPassword = await bcrypt.hash(newPassword, 6);
        const updatedUser = await changeUserPassword(userId, hashedPassword);

        return updatedUser;

    } catch (err) {
        throw err;
    }
}

export const getUserProfileService = async (userId: string) => {

    try {

        const user = await getUserById(userId);
        let profileUrl = user.profileUrl;

        if (user.profileUrl) {
            profileUrl = await getPreSignedUrl(user.profileUrl);
        }

        return {
            ...user,
            profileUrl: profileUrl,
        };
        
    } catch (err) {
        throw err;
    }

}

export const getSuggestedArtistsService = async (amount: number) => {
    
    try {

        // const 
        const artists = await getSuggestedArtistsRepo(amount);

        return await Promise.all(artists.map(async (artist: any) => {
            return {
                userId: artist.userId,
                displayName: artist.displayName,
                description: artist.description,
                artistRate: artist.artistRate,
                profileUrl: artist.profileUrl ? await getPreSignedUrl(artist.profileUrl) : null,
            }
        }));
        
    } catch (err) {
        throw err;
    }
}

export const updateUserInfo = async (userId: string, payload: any) => {

    try {

        const user = await updateUserById(userId, payload);

        const { password, ...userResponse } = user;

        return userResponse;

    } catch (err) {
        throw err;
    }

}
interface changeProfileArgs {
    userId: string;
    picture: Buffer<ArrayBuffer>;
    contentType: any;
}

export const changeUserProfilePicture = async ({
    userId,
    picture,
    contentType,
}: changeProfileArgs) => {

    const filename = `profile-${userId}-${crypto.randomUUID()}`;
    
    await uploadImage({
        filename,
        folder: `user-profile`,
        picture,
        contentType,
    });

    const fullpath = `user-profile/${filename}`;

    await updateUserById(userId, {
        profileUrl: fullpath,
    });

    const presignedUrl = await getPreSignedUrl(fullpath);

    return presignedUrl;

}


export const getUserByDisplayNameService = async (displayName: string[]) => {

    try {

        const artist = await getUserByDisplayName(displayName);

        /* @ts-ignore */
        const artistWithImage = await Promise.all(artist.map(async (artist) => {
            return {
                ...artist,
                profileUrl: artist.profileUrl ? await getPreSignedUrl(artist.profileUrl) : null,
            }
        })) 

        return artistWithImage

    } catch (err) {
        throw err
    }
}