import promptpay from "promptpay-qr";

import * as QRCode from 'qrcode'
import fs from 'fs'
import path from "path";
import { getPreSignedUrl, uploadImage } from '../repositories/objectStorage';

export const generatePromptPayQR = async (promptPayId: string, amount?: number) => {
  try {
    // Generate PromptPay QR payload
    const qrCodePayload: string = promptpay(promptPayId, { amount });

    // Generate QR Code as a data URL (base64)
    const qrCodeDataUrl: string = await QRCode.toDataURL(qrCodePayload);

    // Convert base64 to an image file
    const base64Data: string = qrCodeDataUrl.replace(/^data:image\/png;base64,/, "");
    fs.writeFileSync("promptpay.png", base64Data, "base64");

    const filename = `${promptPayId}-${crypto.randomUUID()}`
    const folder = 'qrcode'
    const filePath = "/Users/griszly/ProjectSW2/my-commisions-server/promptpay.png"
    const fileStream = fs.readFileSync(filePath)
    const fileExtension = path.extname(filePath).toLowerCase()

    const mimeTypeMap: Record<string, string> = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
    };

    const mimeType = mimeTypeMap[fileExtension] || "application/octet-stream";

    const payload = {
        filename:filename,
        folder:folder,
        picture:fileStream,
        contentType:mimeType
    }

    const res = await uploadImage(payload)
    // console.log(res)

    const signedUrl = await getPreSignedUrl(`${folder}/${res.savedFilename}`)

    console.log("✅ QR Code generated: promptpay.png")
    return signedUrl
  } catch (error) {
    console.error("❌ Error generating QR Code:", error)
    throw error
  }
};
