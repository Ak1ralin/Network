import { AppError } from "../utils/AppError";
import {
    createReport,
    getReportById,
    getReportsByUser,
    updateReportById,
    deleteReportById,
} from "../repositories/report";

// Create Report Service
export const createReportService = async (reporterId: string, body: any) => {
    try {
        const reportData = {
            reporterId: reporterId,
            ...body,
            reportStatus: "PENDING",
        };
        const report = await createReport(reportData);
        return report;
    } catch (error) {
        throw new AppError("Error creating report", 500);
    }
};

// Get Report by ID
export const getReportService = async (reportId: string, userId: string) => {
    try {
        const report = await getReportById(reportId);

        if (!report) {
            throw new AppError("Report not found", 404);
        }

        // Check if the user is authorized to access the report
        if (report.reporterId !== userId) {
            throw new AppError("Unauthorized access", 403);
        }

        return report;
    } catch (error) {
        throw error;
    }
};

// Get Report History for a User
export const getReportHistoryService = async (userId: string) => {
    try {
        const reports = await getReportsByUser(userId);

        if (reports.length === 0) {
            throw new AppError("No reports found", 404);
        }

        return reports;
    } catch (error) {
        throw error;
    }
};

// Admin: Get Report by ID (Admin can access all reports)
export const getReportAdminService = async (reportId: string) => {
    try {
        const report = await getReportById(reportId);

        if (!report) {
            throw new AppError("Report not found", 404);
        }

        return report;
    } catch (error) {
        throw error;
    }
};

// Admin: Get All Reports from a User
export const getAllReportFromUserAdminService = async (userId: string) => {
    try {
        const reports = await getReportsByUser(userId);

        if (reports.length === 0) {
            throw new AppError("No reports found for this user", 404);
        }

        return reports;
    } catch (error) {
        throw error;
    }
};

// Admin: Edit Report (Admin can edit reports)
export const editReportAdminService = async (reportId: string, updateData: any) => {
    try {
        // Ensure we can't update certain fields
        if (updateData.reportId || updateData.createdAt) {
            throw new AppError("Cannot edit reportId or createdAt fields", 403);
        }

        const updatedReport = await updateReportById(reportId, updateData);

        if (!updatedReport) {
            throw new AppError("Report not found", 404);
        }

        return updatedReport;
    } catch (error) {
        throw error;
    }
};

// Admin: Delete Report
export const deleteReportAdminService = async (reportId: string) => {
    try {
        const report = await getReportById(reportId);

        if (!report) {
            throw new AppError("Report not found", 404);
        }

        await deleteReportById(reportId);
        return { message: "Report deleted successfully" };
    } catch (error) {
        throw error;
    }
};
