import { getPasswordResetTokenByTokenRepo } from "../repositories/PasswordReset";
import { getUserByEmail } from "../repositories/user";
import { deletePasswordResetToken } from "../repositories/token";
import { forgetPasswordService } from "./user";

/*
After User use link to reset password
*/
export const newPasswordService = async (
    password: string,
    token: string,
) => {

    const existingToken = await getPasswordResetTokenByTokenRepo(token)

    if (!existingToken) {
        return { success: 0, error: "Invalid token" }
    }

    const hasExpired = new Date(existingToken.expires) < new Date()

    if (hasExpired) {
        return { success: 0, error: "Token has expired!" }
    }

    const existingUser = await getUserByEmail(existingToken.email);

    if (!existingUser) {
        return { success: 0, error: "Email does not exist!" }
    }

    //Call UPDATE user 
    const updatedUser = await forgetPasswordService({ userId: existingUser.userId, password: password })
    
    //Change this part to delete token in db
    await deletePasswordResetToken(existingToken.id)

    return { success: 1, user: updatedUser }
}