import { createChatroom, getMessageByChatId, getChatroomByUserId, createMessage, checkHasChatbyUserId, getChatroomById, } from "../repositories/chat"
import { getCommissionById } from "../repositories/commission";
import { getPreSignedUrl } from "../repositories/objectStorage";
import { AppError } from "../utils/AppError"

export const getChatroomService = async (userId: string) => {

    try {
        const chatrooms = await getChatroomByUserId(userId);

        if (!chatrooms) {
            throw new AppError("Chatroom not found", 404)
        }

        return chatrooms
    } catch (error) {
        throw error
    }
}



export const createChatroomService = async (creatorId: string, memberId: string) => {
    try {

        const hasChat = await checkHasChatbyUserId(creatorId, memberId)
        console.log("hasChat = ", hasChat)
        if (hasChat.length) {
            return hasChat
        }

        const newChatroom = await createChatroom(creatorId, memberId)
        return newChatroom

    } catch (error) {
        throw error
    }
}

export const getMessageChatroomService = async (chatRoomId: string) => {
    try {

        const chatRoom = await getMessageByChatId(chatRoomId);
        return {
            messages: chatRoom ? await Promise.all(chatRoom.messages.map(async (message) => {
                if (message.messageType === "COMMISSION") {
                    return {
                        ...message,
                        commission: getCommissionById(message.content),
                    }
                }
                if (message.messageType === "IMAGE") {
                    return {
                        ...message,
                        content: await getPreSignedUrl(message.content),
                    }
                }
                return message;
            })) : [],
            latestCommission: chatRoom ? chatRoom.commissions.reduce((latest, obj) => {
                return new Date(obj.updatedAt) > new Date(latest.updatedAt) ? obj : latest;
            }, chatRoom.commissions[0]) : undefined,
        }

    } catch (error) {
        throw error
    }
}

export const createMessageService = async ({
    chatRoomId,
    senderId,
    content,
    messageType
}: {
    chatRoomId: string;
    senderId: string;
    content: string;
    messageType: "COMMISSION" | "MESSAGE" | "IMAGE";
}) => {
    try {

        let newMessage = await createMessage({
            chatRoomId, content, messageType, senderId
        })

        return newMessage;
    } catch (error) {
        throw error
    }
}

export const getChatroomByIdService = async (chatRoomId: string, userId: string) => {
    try {
        const chatroom = await getChatroomById(chatRoomId)

        if (!chatroom) {
            throw new AppError("Chatroom not found", 404);
        }

        return chatroom
    } catch (error) {
        throw error
    }
}