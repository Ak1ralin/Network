import { getPreSignedUrl, uploadImage } from "../repositories/objectStorage";
import {
    createPost,
    getPostById,
    editPost,
    getPostFromUser,
    getRandomPosts,
    hidePost,
    getPostByQuery,
    getBoostedPosts,
    getBoostedPostsFromUser,
    getNonBoostedPosts,
    getRandomBoostedPosts,
    getRandomNonBoostedPosts,
    editPostBoostDate,
} from "../repositories/post";
import { getUserById } from "../repositories/user";
import { AppError } from "../utils/AppError";
import { getUserProfileService, getUserByDisplayNameService } from "./user";

export const createPostService = async (body: any) => {
    try {
        const post = await createPost(body);

        return {
            ...post,
            artist: await getUserProfileService(post.artistId),
        };
    } catch (error) {
        throw error;
    }
};

export const getPostService = async (postId: string, userId: string) => {
    try {
        const post = await getPostById(postId);

        if (!post) {
            throw new AppError("Post not found", 404);
        }

        if (post.isHide && userId !== post.artistId) {
            throw new AppError("Post Unavailable", 403);
        }

        return {
            ...post,
            artist: {
                ...post.User,
                profileUrl: post.User.profileUrl ? await getPreSignedUrl(post.User.profileUrl) : null,
            },
        };
    } catch (err) {
        throw err;
    }
};

export const searchPostService = async (searchQuery: string[], tagQuery: string[]) => {
    try {
        const user = await getUserByDisplayNameService(searchQuery);
        const userIds = user.map((e) => e.userId);

        const searchedPosts = await getPostByQuery(userIds, searchQuery, tagQuery);

        /* @ts-ignore */
        const postsWithImages = await Promise.all(
            searchedPosts.map(async (post) => {
                const { User, ...searchedPostWithoutUser } = post;
                return {
                    ...searchedPostWithoutUser,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    artist: post.User
                        ? {
                              ...post.User,
                              profileUrl: post.User.profileUrl ? await getPreSignedUrl(post.User.profileUrl) : null,
                          }
                        : null,
                };
            })
        );

        return postsWithImages;
    } catch (error) {
        throw error;
    }
};

export const editPostService = async (userId: string, postId: string, postData: any) => {
    try {
        const oldPost = await getPostById(postId);

        if (userId !== oldPost.artistId) {
            console.log(userId, oldPost.artistId);
            throw new AppError("Access Denied: Post Owner Mismatch", 403);
        }

        const post = await editPost(postId, postData);
        const { User, ...postWithOutUser } = post;
        const { password, ...userResponse } = User;

        return {
            ...postWithOutUser,
            artist: {
                ...userResponse,
                profileUrl: User.profileUrl ? await getPreSignedUrl(User.profileUrl) : null,
            },
        };
    } catch (err) {
        throw err;
    }
};

export const getUserPostService = async (requestUserId: string, targetUserId: string) => {
    try {
        const posts = await getPostFromUser(targetUserId);

        if (!posts) {
            throw new AppError("Posts not found", 404);
        }

        const flattenPosts = posts
            .filter((post: any) => !(post.isHide && requestUserId !== post.artistId))
            .map((post: any) => {
                return { ...post, postTags: post.postTags.map((tag: any) => tag.postTag) };
            });

        /* @ts-ignore */
        const postsWithImages = await Promise.all(
            flattenPosts.map(async (post) => {
                return {
                    ...post,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                };
            })
        );

        const user = await getUserProfileService(targetUserId);

        return {
            posts: postsWithImages,
            artist: user,
        };
    } catch (err) {
        throw err;
    }
};

interface uploadPostImagesArgs {
    files: { fieldname: string; filename: string; buffer: Buffer; mimetype: string }[];
    postId: string;
}

export const uploadPostImages = async ({ files, postId }: uploadPostImagesArgs) => {
    try {
        const uploadPromises = files.map((file) => {
            const { buffer, mimetype, fieldname } = file;
            const formattedFilename = `post-image-${fieldname[6]}-${postId}-${crypto.randomUUID()}`;

            return uploadImage({
                filename: formattedFilename,
                picture: buffer,
                contentType: mimetype,
                folder: `posts`,
            });
        });

        const uploadResults = await Promise.all(uploadPromises);
        let updateSchema: any = {};

        uploadResults.map(({ savedFilename }) => {
            const idx = Number(savedFilename[11]);
            switch (idx) {
                case 1:
                    updateSchema.picUrl1 = `posts/${savedFilename}`;
                    break;
                case 2:
                    updateSchema.picUrl2 = `posts/${savedFilename}`;
                    break;
                case 3:
                    updateSchema.picUrl3 = `posts/${savedFilename}`;
                    break;
                case 4:
                    updateSchema.picUrl4 = `posts/${savedFilename}`;
                    break;
            }
        });

        await editPost(postId, updateSchema);

        const presignedUrls = await Promise.all(
            uploadResults.map(({ savedFilename }) => {
                return getPreSignedUrl(`posts/${savedFilename}`);
            })
        );

        return presignedUrls;
    } catch (err) {
        throw err;
    }
};

export const getRandomPostsService = async () => {
    try {
        const posts = await getRandomPosts();
        const postsWithImages = await Promise.all(
            posts.map(async (post: any) => {
                const { User, ...postWithOutArtist } = post;
                const { password, email, firstName, lastName, phone, artistRate, enabled2FA, ...userInfo } = User;
                return {
                    ...postWithOutArtist,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    postTags: post.postTags.map((tag: any) => tag.postTag),
                    artist: {
                        ...userInfo,
                        profileUrl: User.profileUrl ? await getPreSignedUrl(User.profileUrl) : null,
                    },
                };
            })
        );

        return postsWithImages;
    } catch (err) {
        console.error(err);
        throw err;
    }
};

export const toggleHideStatus = async (postId: string) => {
    const post = await hidePost(postId);
    return {
        ...post,
        picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
        picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
        picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
        picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
    };
};

export const getBoostedPostsFromUserService = async (requestUserId: string, targetUserId: string) => {
    try {
        if (requestUserId !== targetUserId) {
            throw new AppError("Access Denied: Unauthorized to view boosted posts", 403);
        }

        const posts = await getBoostedPostsFromUser(targetUserId);

        if (!posts.length) {
            throw new AppError("No boosted posts found", 404);
        }

        const postsWithImages = await Promise.all(
            posts.map(async (post: any) => {
                return {
                    ...post,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    postTags: post.postTags.map((tag: any) => tag.postTag),
                };
            })
        );

        return postsWithImages;
    } catch (err) {
        throw err;
    }
};

export const getBoostedPostsService = async () => {
    try {
        const posts = await getBoostedPosts();

        const postsWithImages = await Promise.all(
            posts.map(async (post: any) => {
                return {
                    ...post,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    postTags: post.postTags.map((tag: any) => tag.postTag),
                };
            })
        );

        return postsWithImages;
    } catch (err) {
        throw err;
    }
};

export const getNonBoostedPostsService = async () => {
    try {
        const posts = await getNonBoostedPosts();

        const postsWithImages = await Promise.all(
            posts.map(async (post: any) => {
                const { User, ...postWithOutArtist } = post;
                const { password, email, firstName, lastName, phone, artistRate, enabled2FA, ...userInfo } = User;
                return {
                    ...postWithOutArtist,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    postTags: post.postTags.map((tag: any) => tag.postTag),
                    artist: {
                        ...userInfo,
                        profileUrl: User.profileUrl ? await getPreSignedUrl(User.profileUrl) : null,
                    },
                };
            })
        );

        return postsWithImages;
    } catch (err) {
        throw err;
    }
};

export const getRandomBoostedPostsService = async () => {
    try {
        const numPost = 20;
        const posts = await getRandomBoostedPosts(numPost);

        return await Promise.all(
            posts.map(async (post: any) => {
                const { User, ...postWithOutArtist } = post;
                const { password, email, firstName, lastName, phone, artistRate, enabled2FA, ...userInfo } = User;
                return {
                    ...postWithOutArtist,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    postTags: post.postTags.map((tag: any) => tag.postTag),
                    artist: {
                        ...userInfo,
                        profileUrl: User.profileUrl ? await getPreSignedUrl(User.profileUrl) : null,
                    },
                };
            })
        );
    } catch (err) {
        throw err;
    }
};

export const getRandomNonBoostedPostsService = async () => {
    try {
        const numPost = 20;
        const posts = await getRandomNonBoostedPosts(numPost);

        return await Promise.all(
            posts.map(async (post: any) => {
                const { User, ...postWithOutArtist } = post;
                const { password, email, firstName, lastName, phone, artistRate, enabled2FA, ...userInfo } = User;
                return {
                    ...postWithOutArtist,
                    picUrl1: post.picUrl1 ? await getPreSignedUrl(post.picUrl1) : null,
                    picUrl2: post.picUrl2 ? await getPreSignedUrl(post.picUrl2) : null,
                    picUrl3: post.picUrl3 ? await getPreSignedUrl(post.picUrl3) : null,
                    picUrl4: post.picUrl4 ? await getPreSignedUrl(post.picUrl4) : null,
                    postTags: post.postTags.map((tag: any) => tag.postTag),
                    artist: {
                        ...userInfo,
                        profileUrl: User.profileUrl ? await getPreSignedUrl(User.profileUrl) : null,
                    },
                };
            })
        );
    } catch (err) {
        throw err;
    }
};

export const cancelPostBoostService = async (userId: string, postId: string) => {
    try {
        const oldPost = await getPostById(postId);

        if (userId !== oldPost.artistId) {
            console.log(userId, oldPost.artistId);
            throw new AppError("Access Denied: Post Owner Mismatch", 403);
        }

        const post = await editPostBoostDate(postId, new Date());

        return post;
    } catch (err) {
        throw err;
    }
};
