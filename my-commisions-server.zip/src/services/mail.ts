import { Resend } from "resend";
import { AppError } from "../utils/AppError";

const resend = new Resend(process.env.RESEND_API_KEY);

export const sendTwoFactorEmail = async (
    email: string,
    token: string
) => {

    const { data, error } = await resend.emails.send({
        from: "MyComMission@resend.dev",
        to: email,
        subject: "2FA code",
        //for html can be write as react
        html: `2FA Code: ${token}`
    })

    if (error) {
        throw new AppError(error.message, 500);
    }
    return { data };

}

export const sendPasswordResetEmail = async (
    email: string,
    token: string,
    pageRoute: string
) => {

    //Todo: Change to proper link
    const resetLink = `${pageRoute}?token=${token}`;

    const { data, error } = await resend.emails.send({
        from: "MyComMission@resend.dev",
        to: email,
        subject: "Reset password",

        // for html can be write as react
        html: `Please click to reset password here:${resetLink}`
    })

    if (error) {
        return { error }
    }

    if (data) {
        return { data }
    }
}