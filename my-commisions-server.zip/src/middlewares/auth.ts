import { NextFunction, Request, Response } from "express"
import jwt from "jsonwebtoken"
import { config } from "dotenv";
import { AppError } from "../utils/AppError";

config();

export const verifyToken = async (req: Request, res: Response, next: NextFunction) => {

    try {

        let token = req.cookies.authToken;
        // console.log(token);

        if (!token) {
            res.status(403).send("Access Denied")
            return;
        }

        const verified = jwt.verify(token, process.env.JWT_SECRET!);

        /* @ts-ignore */
        if (!verified || !verified.id) {
            res.status(400).json({ message: "Invalid token payload" });
            return;
        }

        (req as any).user = verified;

        next();

    } catch (error) {
        // console.error(error);
        res.status(500).send(error);
        return;
    }

}

export const authorizeAdmin = (req: Request, res: Response, next: NextFunction) => {
    const token = req.cookies?.authToken;
    
    if (!token) {
        res.status(401).send("Unauthorized");
        return;
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET!);
        (req as any).admin = decoded; 
        next();
        return;
    } catch (error) {
        res.status(403).json({ message: "Forbidden" });
        return;
    }
};