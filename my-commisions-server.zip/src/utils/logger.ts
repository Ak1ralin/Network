import winston from "winston";
import morgan from "morgan";
import kleur from "kleur";

const { combine, timestamp, printf, align } = winston.format;

const getStatusColor = (status: number) => {
    const statusGroup = Math.floor(status / 100);
    switch (statusGroup) {
        case 5: return kleur.red;
        case 4: return kleur.yellow;
        case 3: return kleur.cyan;
        case 2: return kleur.green;
        default: return kleur.white;
    }
};

const logger = winston.createLogger({
    level: "info",
    format: combine(
        timestamp({
            format: "YYYY-MM-DD hh:mm:ss.SSS A",
        }),
        align(),
        printf(({ timestamp, message }) => {
            const parts = String(message).split(" ");
            // console.log(parts);
        
            const method = parts[5];
            const route = parts[6];
            const httpInfo = parts[7];
            const statusCode = Number(parts[8]); 
            // const source = // last 13 tokens   
            const color = getStatusColor(statusCode);         
            return color(`[${timestamp}] ${method} ${route} ${httpInfo} ${statusCode}`);
        })
    ),
    transports: [
        new winston.transports.Console(),
    ],
});

const stream = {
    write: (message: string) => {
        logger.info(message.trim())
    },
};

const morganMiddleware = morgan("combined", { stream });

export default morganMiddleware;
