import express, { Request, Response } from "express"
import dotenv from "dotenv"
import router from "./routes";
import logger from "./utils/logger"
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import { setupSwagger } from "./config/swaggerConfig";

dotenv.config();

const app = express();

const corsOptions: cors.CorsOptions = {
    origin: true,
    methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
};

app.use(cors(corsOptions));
app.use(express.json());
app.use(bodyParser.json());
app.use(cookieParser());
app.use(logger);
app.use(router);

setupSwagger(app);

app.get("/", (req: Request, res: Response) => {
    res.send(`Server is succesfully running`)
})

export default app;