import http from 'http';
import app from './app';
import dotenv from "dotenv";
import { initializeSocket } from './websocket';

dotenv.config();

const PORT = process.env.PORT || 5001;
const server = http.createServer(app);

initializeSocket(server);

server.listen(PORT, () => {
    console.log(`Server is successfully running at port ${PORT}`);
}).on('error', (err) => {
    console.error('Server failed to start:', err);
});
