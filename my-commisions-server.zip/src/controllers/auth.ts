import { NextFunction, Request, Response } from "express"
import { check2FAService, login2FA, registerService } from "../services/auth";
import { AppError } from "../utils/AppError";
import { sendTwoFactorEmail } from "../services/mail";
import { generateTwoFactorToken } from "../repositories/token";

export const register = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { body } = req;
        const { user, token } = await registerService(body);

        res.cookie("authToken", token, { maxAge: 2 * 24 * 60 * 60 * 100 })

        res.status(200).json({
            user,
            token,
        });
        return;

    } catch (error) {
        next(error);
    }

}

export const login = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { body: { email, password } } = req;

        /* ---------------------------------------------- */
        const { statusCode, message, user, token } = await login2FA({
            email,
            password
        });

        res.cookie("authToken", token, { maxAge: 2 * 24 * 60 * 60 * 100 })

        res.status(statusCode).send({
            message,
            user,
            token,
        })

    } catch (error) {
        next(error);
    }

}

export const check2FA = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const { email, token } = req.body

        console.log(`email: ${email}`);
        console.log(`token: ${token}`);

        if (!token || !email) {
            next(new AppError("Either token or email is not provided", 400));
            return;
        }

        const { user, authToken } = await check2FAService({ email, token })

        res.cookie("authToken", authToken, { maxAge: 2 * 24 * 60 * 60 * 100 })

        res.status(200).json({ user, authToken })

    } catch (error) {
        next(error)
    }

}

export const logout = async (req: Request, res: Response, next: NextFunction) => {
    try {

        if (req.cookies.authToken) {
            res.clearCookie("authToken");
        }

        res.sendStatus(200);
        return;

    } catch (err) {
        next(err);
    }
}

export const sendEmail = async (req: Request, res: Response, next: NextFunction) => {

    const email = req.body.email

    if (!email) {
        res.status(400).json({
            msg: 'Bad Request'
        })
    }

    try {

        const token = (await generateTwoFactorToken(email)).token
        await sendTwoFactorEmail(email, token)

        res.sendStatus(200);

    } catch (err) {
        next(err)
    }
}