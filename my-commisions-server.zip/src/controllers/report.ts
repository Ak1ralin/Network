import { Request, Response, NextFunction } from "express";
import {
    createReportService,
    getReportService,
    getReportHistoryService,
    getReportAdminService,
    getAllReportFromUserAdminService,
    editReportAdminService,
} from "../services/report";
import { AppError } from "../utils/AppError";

/* POST - /report/submit */
export const submitReport = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { body } = req;
        const userId = (req as any).user.id;

        const report = await createReportService(userId, body);

        res.status(200).json({ report });
        return;
    } catch (error) {
        next(error);
    }
};

/* GET - /report/:reportId */
export const getReport = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { reportId } = req.params;
        const userId = (req as any).user.id;

        const report = await getReportService(reportId, userId);

        res.status(200).json({ report });
        return;
    } catch (error) {
        next(error);
    }
};

/* GET - /report/history */
export const getReportHistory = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const userId = (req as any).user.id;

        const reports = await getReportHistoryService(userId);

        res.status(200).json({ reports });
        return;
    } catch (error) {
        next(error);
    }
};

// Admin Routes

/* GET - /report/admin/get/:reportId */
export const getReportAdmin = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { reportId } = req.params;
        return;

        const report = await getReportAdminService(reportId);

        res.status(200).json({ report });
        return;
    } catch (error) {
        next(error);
    }
};

/* POST - /report/admin/get/from/:userId */
export const getAllReportFromUserAdmin = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { userId } = req.params;
        return;

        const reports = await getAllReportFromUserAdminService(userId);

        res.status(200).json({ reports });
        return;
    } catch (error) {
        next(error);
    }
};

/* PATCH - /report/admin/edit/:reportId */
export const editReportAdmin = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { reportId } = req.params;
        const { body } = req;
        return;

        // Prevent admin from editing immutable fields
        if (body.reportId || body.createdAt) {
            throw new AppError("Cannot edit reportId or createdAt fields", 403);
        }

        const updatedReport = await editReportAdminService(reportId, body);

        res.status(200).json({ updatedReport });
        return;
    } catch (error) {
        next(error);
    }
};
