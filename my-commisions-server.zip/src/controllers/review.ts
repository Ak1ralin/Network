import { Request, Response, NextFunction } from "express";
import { createReviewService, 
         deleteReviewService, 
         getReviewService, 
         getReviewsOfUserService, } from "../services/review";
import { AppError } from "../utils/AppError";

export const createReview = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { user } = req as any;
        const { body } = req;

        if (body.revieweeId === user.id) {
            next(new AppError("Users are not allowed to review themselves.", 403));
        }
        
        const review = await createReviewService({ ...body, reviewerId: user.id });
    
        res.status(200).json({ review });

    } catch (error) {
        next(error);
    }
}

export const getReview = async (req: Request, res: Response, next: NextFunction) => {
    try {
        
        const { reviewId } = req.params;
        const review = await getReviewService(reviewId);

        res.status(200).json(review);

    } catch (error) {
        next(error);
    }
}

export const getReviewsOfUser = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { userId } = req.params
        const reviews = await getReviewsOfUserService(userId)

        res.status(200).json(reviews);

    } catch (error) {
        next(error);
    }
}

export const deleteReview = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { reviewId } = req.params
        const { user } = req as any;

        const review = await getReviewService(reviewId)

        if (user.id !== review.reviewerId) {
            return next(new AppError(`Only the owner is allowed to delete this review`, 403))
        }

        const deletedReview = await deleteReviewService(reviewId)
        res.status(200).json(deletedReview)

    } catch (error) {
        next(error)
    }
}