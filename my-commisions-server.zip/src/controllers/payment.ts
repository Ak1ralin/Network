import { Request, Response, NextFunction } from "express"
import { generatePromptPayQR } from "../services/qr"
import {
    createPaymentIntentService,
    addCreditCardService,
    getCreditCardService,
    editCreditCardService,
    createPaymentTransactionService,
    createPostBoostTransactionService
} from "../services/payment";
import { AppError } from "../utils/AppError";

/* POST - /payment/credit-card/add */
export const addCreditCard = async (req: Request, res: Response, next: NextFunction) => {

    try {

        // Expected Body
        // const data = {
        //     number: ...,
        //     expDate: ...,
        //     cvv: ...,
        //     user: userId from jwt.verify,
        // };

        const data = await addCreditCardService(req.body);

        res.status(200).json(data);
        return;

    } catch (error) {
        next(error);
    }

}

/* GET - /payment/credit-card/ */
export const getCreditCard = async (req: Request, res: Response, next: NextFunction) => {

    try {

        // Expected Body
        // const data = {
        //     user: userId from jwt.verify,
        // };

        const data = await getCreditCardService(req.body.user.id);

        res.status(200).json(data);
        return;

    } catch (error) {
        next(error);
    }
}

/* PATCH - /payment/credit-card/edit */
export const editCreditCard = async (req: Request, res: Response, next: NextFunction) => {

    try {

        // Expected Body
        // const data = {
        //     number: ...,
        //     expDate: ...,
        //     cvv: ...,
        //     user: userId from jwt.verify,
        // };

        const data = await editCreditCardService(req.body);

        res.status(200).json(data);
        return;

    } catch (error) {
        next(error);
    }

}

export const createPaymentIntent = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { amount, currency } = req.body
        // console.log(req.body);
        if (!amount || !currency) {
            // console.log(req.body);
            res.status(400).json({
                msg: "Amount or currency Invalid"
            })
        }

        const paymentIntent = await createPaymentIntentService(amount, currency)
        res.status(200).json({
            client_secret: paymentIntent.client_secret,
            paymentIntent
        })
    } catch (error) {
        console.log(error);
        next(error)
    }
}

export const createQRPayment = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { userPhoneNumber, amount } = req.body

        if (!userPhoneNumber || !amount) {
            res.status(400).json({
                msg: `phone number or amount not found`
            })
        }

        const signedUrl = await generatePromptPayQR(userPhoneNumber, amount);
        res.status(200).json({
            signedUrl
        })

    } catch (error) {
        next(error)
    }
}

export const createPaymentTransaction = async (req: Request, res: Response, next: NextFunction) => {

    try {
        const { customerId, artistId, paymentMethod, commissionId, proposalPrice, stripeId } = req.body

        if (!customerId || !artistId || !paymentMethod || !commissionId || !proposalPrice) {
            // console.log(req.body);
            throw new AppError(`Missing fields`, 400);
        }

        const transactionId = await createPaymentTransactionService({ customerId, artistId, paymentMethod, commissionId, amount: proposalPrice, stripeId });

        res.status(200).json({
            transactionId,
        });

    } catch (error) {
        console.log(error);
        next(error)
    }
}

export const createPostBoostTransaction = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { expiredDate, amount, count, posts } = req.body

        if (!expiredDate || !amount || !count || !posts) {
            throw new AppError(`Missing field`, 400);
        }

        const txnRes = await createPostBoostTransactionService({ expiredDate: new Date(expiredDate), amount, count, posts })

        if (!txnRes) {
            throw new AppError(`Cannot create transaction for posts advertisements`, 500);
        }

        console.log({ txnRes })

        res.status(200).json({
            newPostBoostTxn: txnRes.newPostBoostTxn,
            boostedPost: txnRes.boostedPost
        })

    } catch (error) {
        next(error)
    }
}