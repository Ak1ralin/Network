import { Request, Response, NextFunction } from "express";
import {
    changeUserProfilePicture,
    getUserProfileService,
    updatePasswordService,
    updateUserInfo,
    getUserByDisplayNameService,
    getSuggestedArtistsService
} from "../services/user";
import { AppError } from "../utils/AppError";
import Busboy, { BusboyHeaders } from "@fastify/busboy";
import { verifyEmail } from "../services/auth";

/* GET - /profile/:userId */
export const getUserProfile = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { userId } = req.params;

        if (!userId) {
            next(new AppError("userId is not provided", 400));
        }

        const user = await getUserProfileService(userId);

        res.status(200).json({ user });

    } catch (err) {
        next(err);
    }

}

/* GET - /user?search=xxx */
export const searchUser = async (req: Request, res: Response, next: NextFunction) => {
    const query = req.query.search as string | undefined

    try {
        let searchQuery: string[] = [];

        // No query or empty value, do nothing
        if (!query || query.length === 0) {
            res.status(200).json({ message: "No query provided", users: [] })
            return
        }

        if (query && query.trim().length > 0) {
            const sanitizedSearch = query.replace(/[\s+]+/g, " ").trim();
            searchQuery = searchQuery.concat(sanitizedSearch.split(" ").filter(word => word.length > 0));
        }

        const user = await getUserByDisplayNameService(searchQuery)

        res.status(200).json(user)
        return
        
    } catch (err) {
        next(err)
    }
}

/* PATCH - /change-password/:userId */
export const changePassword = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { userId } = req.params;
        const { oldPassword, newPassword } = req.body;

        const user = await updatePasswordService({ userId, oldPassword, newPassword });

        res.status(200).json({
            user,
        })

    } catch (err) {
        next(err);
    }

}

/* PATCH - /account/:userId */
export const updateUser = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { userId } = req.params;
        if (userId !== (req as any).user.id)
            next(new AppError("Unauthorized", 401))

        const payload = req.body;
        const user = await updateUserInfo(userId, payload);

        res.status(200).json({
            user,
        });

    } catch (err) {
        console.error(err);
        next(err);
    }

}

/* GET - /top-artists/:amount */
export const getSuggestedArtists = async (req: Request, res: Response, next: NextFunction) => {
    
    try {

        const { amount } = req.params;

        if (!amount) {
            next(new AppError("Bad request", 400));
        }

        const artists = await getSuggestedArtistsService(Number(amount));

        res.status(200).json({ artists });
        return;

    } catch (err) {
        next(err);
    }
    
}

/* PATCH - /account/profile-pic/:userId */
export const uploadProfilePicture = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { userId } = req.params;
        if (userId !== (req as any).user.id)
            next(new AppError("Unauthorized", 401))

        const busboy = new Busboy({ headers: (req.headers as BusboyHeaders) });
        let fileReceived = false;

        req.pipe(busboy);

        busboy.on("file", async (name: string, file, info, encoding, mimetype) => {

            fileReceived = true;

            const chunks: Buffer[] = [];
            for await (const chunk of file) {
                chunks.push(chunk);
            }
            const buffer = Buffer.concat(chunks);

            const uploadedFileName = await changeUserProfilePicture({
                userId,
                picture: buffer,
                contentType: mimetype,
            })

            res.status(200).json({
                profileUrl: uploadedFileName,
            })

        })

        busboy.on("finish", () => {
            if (!fileReceived) {
                next(new AppError("No Image provided", 400));
            }
        });

        busboy.on('error', (err) => {
            next(err);
        });

    } catch (err) {
        console.error(err);
        next(err);
    }
}

/* POST - /user/enable-2fa/:userId */
export const enable2FA = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { userId } = req.params;
        
        await verifyEmail({ userId }); 

        res.status(200).json({
            message: `A verification email is sent`,
        })

    } catch (err) {
        next(err);
    }

}