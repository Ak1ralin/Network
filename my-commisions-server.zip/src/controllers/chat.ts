import { NextFunction, Request, Response } from "express"
import { createChatroomService, createMessageService, getChatroomByIdService, getChatroomService, getMessageChatroomService } from "../services/chat"
import { AppError } from "../utils/AppError"
import { getSocketInstance } from "../websocket"

export const getUserChatroom = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const userId = req.params.userId
        if (!userId) {
            next(new AppError("Bad request", 400));
        }

        const chatrooms = await getChatroomService(userId)

        res.status(200).json({
            chatrooms,
        })

    } catch (error) {
        next(error)
    }
}

export const createMessage = async (req: Request, res: Response, next: NextFunction) => {
    
    try {
        const { chatRoomId, senderId, content, messageType } = req.body

        if (!chatRoomId || !senderId || !content || !messageType) {
            next(new AppError("Bad request", 400));
        }
        
        const newMessage = await createMessageService({ chatRoomId, senderId, content, messageType })
        
        const io = getSocketInstance();
        io.to(newMessage.chatRoomId).emit("receiveMessage", {
            newMessage,
        })

        res.status(200).json({
            newMessage
        })

    } catch (error) {

    }
}

export const getMessageChatroom = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { chatroomId } = req.params

        if (!chatroomId) {
            throw new AppError("Bad Request", 400);
        }
        
        const chatRoom = await getMessageChatroomService(chatroomId)
        
        res.status(200).json({
            chatRoom
        })
        
    } catch (error) {
        next(error)
    }
}


export const createChatroom = async (req: Request, res: Response, next: NextFunction) => {
    
    try {
        const { creatorId, memberId } = req.body
        
        if (!creatorId || !memberId) {
            throw new AppError("Bad Request", 400);
        }

        const chatroom = await createChatroomService(creatorId, memberId)

        res.status(200).json({
            chatroom,
        })
        
    } catch (error) {
        next(error)
    }

}

export const getChatroomInformation = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { chatRoomId } = req.params
        const userId = req.params.userId

        if(!chatRoomId){
            next(new AppError("Bad Request", 400));
        }

        const chatroom = await getChatroomByIdService(chatRoomId, userId);

        res.status(200).json({
            chatroom
        })

    } catch (error) {
        next(error)
    }
}
