import { Request, Response, NextFunction } from "express";
import {
    createPostService,
    getPostService,
    editPostService,
    getUserPostService,
    uploadPostImages,
    getRandomPostsService,
    searchPostService,
    getBoostedPostsService,
    getNonBoostedPostsService,
    getRandomBoostedPostsService,
    getRandomNonBoostedPostsService,
    getBoostedPostsFromUserService,
    cancelPostBoostService,
} from "../services/post";
import Busboy, { BusboyHeaders } from "@fastify/busboy";
import { AppError } from "../utils/AppError";

/* POST - /post/create */
export const createPost = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { user } = req as any;
        const { body } = req;

        const post = await createPostService({ ...body, artistId: user.id });

        res.status(200).json({ post });
        return;
    } catch (error) {
        next(error);
    }
};

/* GET - /post/:postId */
export const getPost = async (req: Request, res: Response, next: NextFunction) => {
    try {
        // Expected Body
        // const body = {
        //     postId: ...,
        //     user: userId from jwt.verify,
        // };

        const { postId } = req.params;
        const userId = (req as any).user.id;

        const data = await getPostService(postId, userId);

        res.status(200).json(data);
        return;
    } catch (error) {
        next(error);
    }
};

/* GET - /post?search=xxx&tags=xxx*/
export const searchPosts = async (req: Request, res: Response, next: NextFunction) => {
    const search = req.query.search as string | undefined;
    const tags = req.query.tags as string | undefined;

    try {
        let searchQuery: string[] = [];
        let tagQuery: string[] = [];

        if ((!search || search.length === 0) && (!tags || tags.length === 0)) {
            res.status(200).json({ message: "No search or tags provided", posts: [] });
            return;
        }

        if (search && search.trim().length > 0) {
            const sanitizedSearch = decodeURIComponent(search)
                .replace(/[\s+]+/g, " ")
                .trim();
            searchQuery = searchQuery.concat(sanitizedSearch.split(" ").filter((word) => word.length > 0));
            searchQuery = searchQuery.map((e) => e.replace("-", " ")).flat();
        }

        if (tags && tags.trim().length > 0) {
            const sanitizedTags = decodeURIComponent(tags)
                .replace(/[\s+]+/g, " ")
                .trim();
            tagQuery = tagQuery.concat(sanitizedTags.split(" ").filter((word) => word.length > 0));
            tagQuery = tagQuery.map((e) => e.replace("_", " ")).flat();
        }

        const posts = await searchPostService(searchQuery, tagQuery);

        res.status(200).json({ message: "OK", posts });
        return;
    } catch (err) {
        next(err);
    }
};

/* PATCH - /post/:postId */
export const editPost = async (req: Request, res: Response, next: NextFunction) => {
    try {
        // Expected Body
        // const newPostData = {
        //     name: "title",
        //     description: "description",
        //     tags: ["Anime/Manga", "Chibi"],
        //     price: 999,
        //     samples: ["http://test.url", "http://image.here"],
        //     user: userId from jwt.verify,
        // };

        const { postId } = req.params;
        const { body } = req;
        const { user } = req as any;
        const data = await editPostService(user.id, postId, req.body);

        res.status(200).json({ post: data });
        return;
    } catch (error) {
        next(error);
    }
};

/* PATCH /post/upload/:postId */
export const updatePostImages = async (req: Request, res: Response, next: NextFunction) => {
    const { postId } = req.params;
    const bb = Busboy({ headers: req.headers as BusboyHeaders });
    const files: { fieldname: string; filename: string; buffer: Buffer; mimetype: string }[] = [];

    bb.on("file", async (fieldname, file, filename, encoding, mimetype) => {
        const chunks: Buffer[] = [];
        for await (const chunk of file) {
            chunks.push(chunk);
        }
        files.push({ fieldname, filename, buffer: Buffer.concat(chunks), mimetype });
    });

    bb.on("finish", async () => {
        if (files.length === 0) {
            next(new AppError("No files uploaded", 400));
        }

        try {
            const urls = await uploadPostImages({ files, postId });
            res.status(200).json({ message: "Files uploaded successfully", urls });
            return;
        } catch (error) {
            next(error);
        }
    });

    req.pipe(bb);
};

/* GET - /post/from/:userId */
export const getAllPostFromUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
        // Expected Body
        // const body = {
        //     userId: ..., (user who requested)
        //     user: userId from jwt.verify,
        // };

        const targetUserId = req.params.userId;
        const userId = (req as any).user.id;

        const { posts, artist } = await getUserPostService(userId, targetUserId);

        res.status(200).json({ posts, artist });
        return;
    } catch (error) {
        console.error(error);
        next(error);
    }
};

/* GET - /post/random */
export const getFeedPosts = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const posts = await getRandomPostsService();
        res.status(200).json({ posts });
    } catch (err) {
        next(err);
    }
};

/* GET - /post/boost/from/:userId */
export const getBoostedPostsFromUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const targetUserId = req.params.userId;
        const requestUserId = (req as any).user.id;

        const data = await getBoostedPostsFromUserService(requestUserId, targetUserId);
        res.status(200).json(data);
    } catch (error) {
        next(error);
    }
};

/* GET - /post/get/boost */
export const getAllBoostedPosts = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const posts = await getBoostedPostsService();
        res.status(200).json({ posts });
    } catch (err) {
        next(err);
    }
};

/* GET - /post/get/non-boost */
export const getAllNonBoostedPosts = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const posts = await getNonBoostedPostsService();
        res.status(200).json({ posts });
    } catch (err) {
        next(err);
    }
};

/* GET - /post/random/boost */
export const getRandomBoostedPosts = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const posts = await getRandomBoostedPostsService();
        res.status(200).json({ posts });
    } catch (err) {
        next(err);
    }
};

/* GET - /post/random/non-boost */
export const getRandomNonBoostedPosts = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const posts = await getRandomNonBoostedPostsService();
        res.status(200).json({ posts });
    } catch (err) {
        next(err);
    }
};

/* PATCH - /post/cancel-boost/:postId */
export const cancelPostBoost = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { postId } = req.params;
        const userId = (req as any).user.id;

        const data = await cancelPostBoostService(userId, postId);

        res.status(200).json({ post: data });
        return;
    } catch (error) {
        next(error);
    }
};
