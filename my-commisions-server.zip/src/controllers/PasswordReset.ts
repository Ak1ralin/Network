import { NextFunction, Request, Response } from 'express'
import { newPasswordService } from '../services/new-password'
import { resetPassword } from '../services/reset-password'

export const sendPasswordResetToken = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    const email = req.body.email

    if (!email) {
        res.status(400).json({ error: 'Bad Request', msg: "Email not found!" });
        return;
    }

    try {
        
        const { resetPageRoute } = req.body;
        const { success, passwordResetToken, mail } = await resetPassword(email, resetPageRoute);

        if (success === 0) {
            res.status(400).json({ error: 'Bad Request', msg: "User not found!" });
            return;
        }

        if (mail?.error) {
            res.status(400).json({ error: 'Bad Request', msg: "Cannot send email!" });
            return;
        }

        res.status(200).json({ data: passwordResetToken })

    } catch (error) {
        next(error)
    }
}

export const resetForgotPassword = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    const password = req.body.newPassword
    const token = req.params.token

    if (!token) {
        res.status(400).json({ error: 'Bad Request', msg: "Invalid found!" });
        return;
    }

    try {
        const { success, user, error } = await newPasswordService(password, token)

        if (!success) {
            res.status(400).json({ error: 'Bad Request', msg: error });
            return;
        }

        res.status(200).json(user);
        return;

    } catch (error) {
       next(error)
    }
}