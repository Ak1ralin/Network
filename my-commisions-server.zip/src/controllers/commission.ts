import { Request, Response, NextFunction } from "express";
import { AppError } from "../utils/AppError";
import { changeBriefToProposal, changeProposalToWorking, changeWorkingToShipped, createCommissionService, editBriefService, finishCommission, getArtworksByUserService, getCommissionByIdService, rejectBriefService, uploadArtworkService } from "../services/commission";
import { getSocketInstance } from "../websocket";
import { createMessageService } from "../services/chat";


/* Commission Info ---------------------------------------------------------------------------------- */

export const getCommissionById = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { commissionId } = req.params;
        const commission = await getCommissionByIdService(commissionId);

        if (!commission) {
            throw new AppError("Commission not found", 404);
        }

        res.status(200).json({ commission });
        return;
    } catch (error) {
        next(error);
    }
}

// export const

/* Message broadcaster via socket */
export const sendCommissionToClients = async (commission: any, senderId: string) => {
    
    try {

        const newMessage = await createMessageService({
            chatRoomId: commission.chatRoomId,
            content: commission.commissionId,
            messageType: "COMMISSION",
            senderId,
        });

        const socket = getSocketInstance();
        socket.to(newMessage.chatRoomId).emit("receiveMessage", {
            newMessage: {
                ...newMessage,
                commission,
            }
        });

    } catch (err) {
        throw err;
    }
}

/* Life Cycle ---------------------------------------------------------------------------------- */
export const createCommission = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { body } = req;
        const userId = (req as any).user.id;

        if (userId !== body.customerId) {
            throw new AppError("Unauthorized", 401);
        }

        const commission = await createCommissionService(body);
        res.status(200).json({ commission });

        await sendCommissionToClients(commission, userId);
        return;

    } catch (error) {
        next(error);
    }
}

export const acceptBrief = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { body } = req;
        const userId = (req as any).user.id;
        const { commissionId } = req.params;

        if (userId !== body.artistId) {
            throw new AppError("Unauthorized", 401);
        }

        const { commission } = await changeBriefToProposal(commissionId, body);
        await sendCommissionToClients(commission, userId);
        res.status(200).json(body);
        return;

    } catch (err) {
        next(err);
    }
}

export const editBrief = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { body } = req;
        const userId = (req as any).user.id;
        const { commissionId } = req.params;

        if (userId !== body.customerId) {
            throw new AppError("Unauthorized", 401);
        }

        const { commission } = await editBriefService(commissionId, body);
        await sendCommissionToClients(commission, userId);
        res.status(200).json(body);
        return;

    } catch (err) {
        next(err);
    }
}

export const rejectBrief = async (req: Request, res: Response, next: NextFunction) => {

    try {

        const { body } = req;
        const userId = (req as any).user.id;
        const { commissionId } = req.params;

        if (userId !== body.artistId) {
            throw new AppError("Unauthorized", 401);
        }

        const { commission } = await rejectBriefService(commissionId);
        await sendCommissionToClients(commission, userId);
        res.sendStatus(200);
        return;

    } catch (err) {
        next(err);
    }
}

export const acceptProposal = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { commissionId } = req.params;
        const { body } = req;
        const userId = (req as any).user.id;

        if (userId !== body.customerId) {
            throw new AppError("Unauthorized", 401);
        }

        const { commission } = await changeProposalToWorking(commissionId, body);
        await sendCommissionToClients(commission, userId);

        res.status(200).json(body);
        return;

    } catch (err) {
        next(err);
    }
}

// export const editProposal =

export const uploadArtwork = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { commissionId } = req.params;
        const { body: { fileType } } = req;
        const data = await uploadArtworkService(commissionId, fileType);

        res.status(200).json(data);
        return;

    } catch (error) {
        next(error);
    }
}

export const sendArtwork = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const { commissionId } = req.params;
        const { body } = req;
        const userId = (req as any).user.id;

        if (userId !== body.artistId) {
            throw new AppError("Unauthorized", 401);
        }

        const { commission, imageUrl, artworkPath } = await changeWorkingToShipped(commissionId, body);
        const newMessage = await createMessageService({
            chatRoomId: commission.chatRoomId,
            content: artworkPath,
            messageType: "IMAGE",
            senderId: commission.artistId,
        });

        const socket = getSocketInstance();
        socket.to(newMessage.chatRoomId).emit("receiveMessage", {
            newMessage: {
                ...{
                    ...newMessage,
                    content: imageUrl, 
                },
                commission,
            }
        });   

        res.status(200).json(body);
        return;
        
    } catch (err) {
        next(err);
    }
}

export const acceptArtwork = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { commissionId } = req.params;
        const { body } = req;
        const userId = (req as any).user.id;

        if (userId !== body.customerId) {
            throw new AppError("Unauthorized", 401);
        }

        const { commission } = await finishCommission(commissionId);
        await sendCommissionToClients(commission, body.customerId);

        res.sendStatus(200);

    } catch (err) {
        next(err);
    }
}

/* GET - /artwork/from/:userId */
export const getArtworksFromUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const targetUserId = req.params.userId;
        const requestUserId = (req as any).user.id;

        const data = await getArtworksByUserService(requestUserId, targetUserId);
        res.status(200).json(data);
    } catch (error) {
        next(error);
    }
};