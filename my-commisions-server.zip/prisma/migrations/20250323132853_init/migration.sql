/*
  Warnings:

  - The values [BRIEF,PROPOSAL] on the enum `MessageType` will be removed. If these variants are still used in the database, this will fail.
  - A unique constraint covering the columns `[commissionId]` on the table `PaymentTransaction` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `updatedAt` to the `Artwork` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `Commission` table without a default value. This is not possible if the table is not empty.
  - Made the column `chatRoomId` on table `Commission` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `amount` to the `PaymentTransaction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `commissionId` to the `PaymentTransaction` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `Review` table without a default value. This is not possible if the table is not empty.
  - Made the column `artistRate` on table `User` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "MessageType_new" AS ENUM ('MESSAGE', 'COMMISSION', 'IMAGE');
ALTER TABLE "Message" ALTER COLUMN "messageType" TYPE "MessageType_new" USING ("messageType"::text::"MessageType_new");
ALTER TYPE "MessageType" RENAME TO "MessageType_old";
ALTER TYPE "MessageType_new" RENAME TO "MessageType";
DROP TYPE "MessageType_old";
COMMIT;

-- DropForeignKey
ALTER TABLE "Commission" DROP CONSTRAINT "Commission_chatRoomId_fkey";

-- DropForeignKey
ALTER TABLE "Commission" DROP CONSTRAINT "Commission_transactionId_fkey";

-- AlterTable
ALTER TABLE "Artwork" ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "Commission" ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL,
ALTER COLUMN "chatRoomId" SET NOT NULL;

-- AlterTable
ALTER TABLE "PaymentTransaction" ADD COLUMN     "amount" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "commissionId" UUID NOT NULL,
ADD COLUMN     "stripeId" TEXT;

-- AlterTable
ALTER TABLE "Post" ADD COLUMN     "transactionId" UUID;

-- AlterTable
ALTER TABLE "Review" ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "description" TEXT NOT NULL DEFAULT 'No bio yet',
ADD COLUMN     "location" TEXT NOT NULL DEFAULT 'Tokyo, Japan',
ALTER COLUMN "artistRate" SET NOT NULL,
ALTER COLUMN "artistRate" SET DEFAULT 0;

-- CreateTable
CREATE TABLE "PostBoostTransaction" (
    "transactionId" UUID NOT NULL,
    "expiredDate" TIMESTAMP(3) NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "count" INTEGER NOT NULL,

    CONSTRAINT "PostBoostTransaction_pkey" PRIMARY KEY ("transactionId")
);

-- CreateIndex
CREATE UNIQUE INDEX "PaymentTransaction_commissionId_key" ON "PaymentTransaction"("commissionId");

-- AddForeignKey
ALTER TABLE "Post" ADD CONSTRAINT "Post_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES "PostBoostTransaction"("transactionId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentTransaction" ADD CONSTRAINT "PaymentTransaction_commissionId_fkey" FOREIGN KEY ("commissionId") REFERENCES "Commission"("_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Commission" ADD CONSTRAINT "Commission_chatRoomId_fkey" FOREIGN KEY ("chatRoomId") REFERENCES "ChatRoom"("chatRoomId") ON DELETE RESTRICT ON UPDATE CASCADE;
