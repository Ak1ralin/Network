-- AlterTable
ALTER TABLE "Artwork" ALTER COLUMN "customerHide" SET DEFAULT true,
ALTER COLUMN "artistHide" SET DEFAULT true;
