-- CreateEnum
CREATE TYPE "ReportType" AS ENUM ('GENERAL', 'COMMISSION', 'USER', 'POST');

-- CreateEnum
CREATE TYPE "ReportStatus" AS ENUM ('PENDING', 'IN_REVIEW', 'APPROVED', 'REJECTED');

-- CreateTable
CREATE TABLE "Report" (
    "reportId" TEXT NOT NULL,
    "reporterId" UUID NOT NULL,
    "reportType" "ReportType" NOT NULL,
    "reportStatus" "ReportStatus" NOT NULL,
    "reportDescription" TEXT NOT NULL,
    "commissionId" UUID,
    "reporteeId" UUID,
    "postId" UUID,
    "moderatorResponse" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Report_pkey" PRIMARY KEY ("reportId")
);

-- CreateIndex
CREATE UNIQUE INDEX "Report_commissionId_key" ON "Report"("commissionId");

-- CreateIndex
CREATE UNIQUE INDEX "Report_postId_key" ON "Report"("postId");

-- AddForeignKey
ALTER TABLE "Report" ADD CONSTRAINT "Report_reporterId_fkey" FOREIGN KEY ("reporterId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Report" ADD CONSTRAINT "Report_reporteeId_fkey" FOREIGN KEY ("reporteeId") REFERENCES "User"("userId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Report" ADD CONSTRAINT "Report_commissionId_fkey" FOREIGN KEY ("commissionId") REFERENCES "Commission"("_id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Report" ADD CONSTRAINT "Report_postId_fkey" FOREIGN KEY ("postId") REFERENCES "Post"("postId") ON DELETE SET NULL ON UPDATE CASCADE;
