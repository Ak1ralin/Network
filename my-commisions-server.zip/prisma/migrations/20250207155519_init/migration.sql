/*
  Warnings:

  - You are about to drop the column `pdfUrl` on the `User` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "User" DROP COLUMN "pdfUrl";

-- CreateTable
CREATE TABLE "CreditCard" (
    "userId" UUID NOT NULL,
    "number" VARCHAR(16) NOT NULL,
    "expDate" VARCHAR(10) NOT NULL,
    "cvv" VARCHAR(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CreditCard_pkey" PRIMARY KEY ("userId")
);

-- AddForeignKey
ALTER TABLE "CreditCard" ADD CONSTRAINT "CreditCard_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;
