/*
  Warnings:

  - You are about to drop the column `postName` on the `Post` table. All the data in the column will be lost.
  - You are about to drop the column `price` on the `Post` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Post" DROP COLUMN "postName",
DROP COLUMN "price",
ALTER COLUMN "isHide" SET DEFAULT false,
ALTER COLUMN "picUrl1" DROP NOT NULL;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "profileUrl" VARCHAR(1024) NOT NULL DEFAULT '';
