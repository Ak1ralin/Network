/*
  Warnings:

  - A unique constraint covering the columns `[commissionId]` on the table `ChatRoom` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "ChatRoom" ADD COLUMN     "commissionId" UUID;

-- CreateIndex
CREATE UNIQUE INDEX "ChatRoom_commissionId_key" ON "ChatRoom"("commissionId");

-- AddForeignKey
ALTER TABLE "ChatRoom" ADD CONSTRAINT "ChatRoom_commissionId_fkey" FOREIGN KEY ("commissionId") REFERENCES "Commission"("_id") ON DELETE SET NULL ON UPDATE CASCADE;
