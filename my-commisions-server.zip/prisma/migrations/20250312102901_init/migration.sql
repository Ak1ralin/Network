-- DropIndex
DROP INDEX "Commission_commissionName_key";

-- AlterTable
ALTER TABLE "Commission" ALTER COLUMN "commissionName" SET DATA TYPE TEXT;
