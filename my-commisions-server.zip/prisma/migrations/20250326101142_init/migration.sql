-- AlterTable
ALTER TABLE "Artwork" ALTER COLUMN "customerHide" SET DEFAULT false,
ALTER COLUMN "artistHide" SET DEFAULT false;
