-- AlterTable
ALTER TABLE "Commission" ALTER COLUMN "proposalPrice" DROP NOT NULL,
ALTER COLUMN "expectedDate" DROP NOT NULL;
