-- CreateEnum
CREATE TYPE "PaymentMethod" AS ENUM ('QRPROMPTPAY', 'CREDITCARD');

-- CreateEnum
CREATE TYPE "Status" AS ENUM ('BRIEF', 'BRIEF_REJECTED', 'PROPOSAL', 'PROPOSAL_REJECTED', 'WORKING', 'FINISHED', 'CANCELED');

-- CreateTable
CREATE TABLE "PaymentTransaction" (
    "transactionId" UUID NOT NULL,
    "customerId" UUID NOT NULL,
    "artistId" UUID NOT NULL,
    "paymentMethod" "PaymentMethod" NOT NULL,
    "receiptReference" TEXT,

    CONSTRAINT "PaymentTransaction_pkey" PRIMARY KEY ("transactionId")
);

-- CreateTable
CREATE TABLE "Commission" (
    "_id" UUID NOT NULL,
    "customerId" UUID NOT NULL,
    "artistId" UUID NOT NULL,
    "status" "Status" NOT NULL,
    "transactionId" UUID,
    "artworkId" TEXT,
    "briefDescription" TEXT NOT NULL,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "budget" DOUBLE PRECISION NOT NULL,
    "proposalPrice" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "Commission_pkey" PRIMARY KEY ("_id")
);

-- CreateTable
CREATE TABLE "Review" (
    "_id" UUID NOT NULL,
    "reviewerId" UUID NOT NULL,
    "revieweeId" UUID NOT NULL,
    "rating" DOUBLE PRECISION NOT NULL,
    "description" TEXT,

    CONSTRAINT "Review_pkey" PRIMARY KEY ("_id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Commission_transactionId_key" ON "Commission"("transactionId");

-- AddForeignKey
ALTER TABLE "PaymentTransaction" ADD CONSTRAINT "PaymentTransaction_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentTransaction" ADD CONSTRAINT "PaymentTransaction_artistId_fkey" FOREIGN KEY ("artistId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Commission" ADD CONSTRAINT "Commission_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Commission" ADD CONSTRAINT "Commission_artistId_fkey" FOREIGN KEY ("artistId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Commission" ADD CONSTRAINT "Commission_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES "PaymentTransaction"("transactionId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Review" ADD CONSTRAINT "Review_reviewerId_fkey" FOREIGN KEY ("reviewerId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Review" ADD CONSTRAINT "Review_revieweeId_fkey" FOREIGN KEY ("revieweeId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;
