-- DropIndex
DROP INDEX "Report_commissionId_key";

-- DropIndex
DROP INDEX "Report_postId_key";
