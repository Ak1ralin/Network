/*
  Warnings:

  - You are about to drop the column `commissionId` on the `ChatRoom` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[chatRoomId]` on the table `Commission` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE "ChatRoom" DROP CONSTRAINT "ChatRoom_commissionId_fkey";

-- DropIndex
DROP INDEX "ChatRoom_commissionId_key";

-- AlterTable
ALTER TABLE "ChatRoom" DROP COLUMN "commissionId";

-- AlterTable
ALTER TABLE "Commission" ADD COLUMN     "chatRoomId" UUID;

-- CreateIndex
CREATE UNIQUE INDEX "Commission_chatRoomId_key" ON "Commission"("chatRoomId");

-- AddForeignKey
ALTER TABLE "Commission" ADD CONSTRAINT "Commission_chatRoomId_fkey" FOREIGN KEY ("chatRoomId") REFERENCES "ChatRoom"("chatRoomId") ON DELETE SET NULL ON UPDATE CASCADE;
