/*
  Warnings:

  - You are about to drop the column `dueDate` on the `Commission` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `Commission` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[commissionName]` on the table `Commission` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `deadline` to the `Commission` table without a default value. This is not possible if the table is not empty.
  - Added the required column `expectedDate` to the `Commission` table without a default value. This is not possible if the table is not empty.
  - Added the required column `state` to the `Commission` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "CommissionState" AS ENUM ('BRIEF', 'BRIEF_REJECTED', 'PROPOSAL', 'PROPOSAL_REJECTED', 'WORKING', 'ARTWORK_SHIPPED', 'ARTWORK_REJECTED', 'FINISHED', 'CANCELED');

-- AlterTable
ALTER TABLE "Commission" DROP COLUMN "dueDate",
DROP COLUMN "status",
ADD COLUMN     "commercialUse" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "commissionName" UUID,
ADD COLUMN     "deadline" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "expectedDate" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "state" "CommissionState" NOT NULL;

-- DropEnum
DROP TYPE "Status";

-- CreateIndex
CREATE UNIQUE INDEX "Commission_commissionName_key" ON "Commission"("commissionName");
