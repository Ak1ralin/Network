-- CreateTable
CREATE TABLE "User" (
    "userId" UUID NOT NULL,
    "birthDate" DATE NOT NULL,
    "firstName" VARCHAR(72) NOT NULL,
    "lastName" VARCHAR(72) NOT NULL,
    "artistFlag" BOOLEAN NOT NULL DEFAULT false,
    "email" VARCHAR(72) NOT NULL,
    "password" VARCHAR(72) NOT NULL,
    "displayName" VARCHAR(72) NOT NULL,
    "phone" CHAR(10) NOT NULL,
    "pdfUrl" VARCHAR(2048),
    "artistRate" DOUBLE PRECISION,
    "enabled2FA" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("userId")
);

-- CreateTable
CREATE TABLE "Post" (
    "postId" UUID NOT NULL,
    "artistId" UUID NOT NULL,
    "postName" VARCHAR(72) NOT NULL,
    "postDescription" VARCHAR(2048),
    "price" DOUBLE PRECISION NOT NULL,
    "isHide" BOOLEAN NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "picUrl1" VARCHAR(2048) NOT NULL,
    "picUrl2" VARCHAR(2048),
    "picUrl3" VARCHAR(2048),
    "picUrl4" VARCHAR(2048),

    CONSTRAINT "Post_pkey" PRIMARY KEY ("postId")
);

-- CreateTable
CREATE TABLE "PostTag" (
    "postId" UUID NOT NULL,
    "postTag" VARCHAR(72) NOT NULL,

    CONSTRAINT "PostTag_pkey" PRIMARY KEY ("postId","postTag")
);

-- CreateTable
CREATE TABLE "VerificationToken" (
    "_id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "VerificationToken_pkey" PRIMARY KEY ("_id")
);

-- CreateTable
CREATE TABLE "TwoFactorToken" (
    "_id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TwoFactorToken_pkey" PRIMARY KEY ("_id")
);

-- CreateTable
CREATE TABLE "TwoFactorConfirmation" (
    "_id" UUID NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "TwoFactorConfirmation_pkey" PRIMARY KEY ("_id")
);

-- CreateTable
CREATE TABLE "PasswordResetToken" (
    "_id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY ("_id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE INDEX "Post_artistId_idx" ON "Post"("artistId");

-- CreateIndex
CREATE UNIQUE INDEX "VerificationToken_token_key" ON "VerificationToken"("token");

-- CreateIndex
CREATE UNIQUE INDEX "VerificationToken_email_token_key" ON "VerificationToken"("email", "token");

-- CreateIndex
CREATE UNIQUE INDEX "TwoFactorToken_token_key" ON "TwoFactorToken"("token");

-- CreateIndex
CREATE UNIQUE INDEX "TwoFactorToken_email_token_key" ON "TwoFactorToken"("email", "token");

-- CreateIndex
CREATE UNIQUE INDEX "TwoFactorConfirmation_userId_key" ON "TwoFactorConfirmation"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON "PasswordResetToken"("token");

-- CreateIndex
CREATE UNIQUE INDEX "PasswordResetToken_email_token_key" ON "PasswordResetToken"("email", "token");

-- AddForeignKey
ALTER TABLE "Post" ADD CONSTRAINT "Post_artistId_fkey" FOREIGN KEY ("artistId") REFERENCES "User"("userId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PostTag" ADD CONSTRAINT "PostTag_postId_fkey" FOREIGN KEY ("postId") REFERENCES "Post"("postId") ON DELETE RESTRICT ON UPDATE CASCADE;
