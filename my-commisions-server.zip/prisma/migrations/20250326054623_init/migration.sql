-- DropIndex
DROP INDEX "Commission_chatRoomId_key";
